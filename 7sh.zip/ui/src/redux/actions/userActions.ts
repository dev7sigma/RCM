export type setUserAction = { type: "SET_USERS"; payload: any[] };
export type getUserHospitalAction = { type: "SET_USERS_HOSPITALS"; payload: any[] };

export const setUsers = (users:any[]) => {
  return {
    type: "SET_USERS",
    payload: users,
  };
};

export const getUserHospitals = (users:any[]) => {
    return {
        type: "SET_USERS_HOSPITALS",
        payload: users,
    };
};