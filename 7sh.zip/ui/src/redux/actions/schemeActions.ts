export type setSchemesAction = { type: "SET_SCHEMES"; payload: any[] };

export const setSchemes = (schemes:any[]) => {
  return {
    type: "SET_SCHEMES",
    payload: schemes,
  };
};