import { setSchemesAction } from "../actions/schemeActions";

export interface schemesState {
    schemes : any[]
}

const initialState = {
    schemes : []
}

export const schemesReducer = (state: schemesState = initialState, action: setSchemesAction) => {

    switch(action.type){
        case 'SET_SCHEMES':
            return { ...state, schemes: action.payload }

        default:
            return state;
    }
}