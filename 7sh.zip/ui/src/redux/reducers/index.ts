import { combineReducers } from "redux";
import { schemesReducer } from './schemesReducer'

const reducers = combineReducers({
    allSchemes: schemesReducer
});

export default reducers;