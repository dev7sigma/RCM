import fetch from 'cross-fetch';
export interface requestData  {
    requestData(method:string, Url:string, payload?:any, uploadFile?:boolean) : Promise<any>
    downloadFile(fileName:string):Promise<any>
}

const RequestApi :requestData = {
    async requestData(method="GET", url, data = {}, uploadFile = false) {
        try{
            const requestObj:any = {
                mode: 'cors',
                credentials: 'include',
                method: method,
                headers: {
                    'Content-Type': uploadFile ? "multipart/form-data" : 'application/json',
                     'Expires' : "-1",
                     'Cache-Control': 'no-cache'
                }
            };
            if(['POST', 'PUT'].includes(method)){
                requestObj['body'] =  JSON.stringify(data) 
            }
            return fetch(url, requestObj).then( (response) => {
                if(response.status === 200){
                    return response.json();  
                }
                else{
                    return {status:'500', message:"Service Error"};
                }
            }).catch( (error) =>  {
                return {status:'500', message:"Service Error"};
            });
        }
        catch(errors){
            return {status:'500', message:"Service Error"};
        }
    },

    async downloadFile(fileName:string)  {
        let downloadEle = document.createElement('a');
        downloadEle.setAttribute('href', `${process.env.PUBLIC_URL}/${fileName}.xlsx`);
        downloadEle.setAttribute('target', '_blank');
        downloadEle.click();
    }

} 

export default RequestApi;

