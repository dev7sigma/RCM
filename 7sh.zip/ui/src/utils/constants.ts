// APP TEXT
export const APP_TITLE = "SEVEN SIGMA HEALTHCARE SOLUTIONS ";
export const FOOTER_TEXT = `Welcome to 7Sigma Health Care`;
// PAGES TITLE
export const PAGE_TITLE_HOME = "Home";
export const PAGE_TITLE_DASHBOARD = "Dashboard";
export const PAGE_TITLE_ADMIN_ADD_USER ="ADD USER";
export const PAGE_TITLE_ADMIN_HOSPITALS = "HOSPITALS";
export const PAGE_TITLE_ADMIN_HOSPITAL = "ADD HOSPITAL";
export const PAGE_TITLE_ADMIN_DEPARTMENTS = "Departments";
export const PAGE_TITLE_ADMIN_SCHEMES = "Schemes";
export const PAGE_TITLE_ADMIN_DOCTORS = "DOCTORS";
export const PAGE_TITLE_PATIENTS = "PATIENTS";
export const PAGE_TITLE_PATIENT = "Patient Registrtaion";
export const PAGE_TITLE_SETTINGS = "Settings";
export const PAGE_TITLE_UIELEMENTS = "UI ELEMENTS"
export const PAGE_TITLE_USERS_LIST = "Users"

// UI CONSTANTS
export const FOOTER_HEIGHT = 30;
export const HEADER_HEIGHT = 60;
export const DRAWER_WIDTH = 250;
// export const PRIMARY_COLOR = '#d8dde0';
export const LOCAL_HOST = 'http://localhost:8080';
// export const LOCAL_HOST = 'https://7sinppjava.azurewebsites.net';
export const AZURE_DEV_HOST = 'https://7sinppjava.azurewebsites.net';

// API Endpoints
export const API = {
    getAllUsers:'/users',
    searchHospital: '/hospitals/search',// hospital/keyword,
    searchUsers:'/users/',
    submitUser:'/users',
    submitHospital:"/hospital",
    HOSPITALS_URL:'/hospitals',
    USER_HOSPITAL_MAP:'/user/hospital/create',
    USER_HOSPITAL_UMMAP:'/user/hospital/delete',
    DEPARMENTS:'/departments',
    SCHEMES:'/schemes',
    DOCTORS : '/doctors',
    PATIENTS:'/patients',
    mapDoctorHospital:LOCAL_HOST+'/hospital/doctor/create',
    unmapDoctorsHospital:LOCAL_HOST+'/hospital/doctor/delete',
    mapDepartmentsHospital:LOCAL_HOST+'/hospital/department/create',
    unmapDepartmentsHospital:LOCAL_HOST+'/hospital/department/delete',
    userBulkUploadUrl :LOCAL_HOST+'/userBulk',
}

export const SCHEMES = [
    {
      key:'ECHS',
      value:'ECHS'
    },
    {
      key:'ESI',
      value:'ESI'
    },
    {
      key:'KASP',
      value:'KASP'
    },
    {
      key:'TPA',
      value:'TPA'
    },
    {
      key:'Corporate',
      value:'Corporate'
    }
  ];

export const defaultDoctorData = {
  id:0,
  name:"",
  regNo:'',
  department:'',
  email:'',
  qualification:'',
  contactNumber:''
};
