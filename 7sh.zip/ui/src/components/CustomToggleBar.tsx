import React, { useState,  useEffect  } from "react";
import ToggleButton from '@material-ui/lab/ToggleButton';
import { withStyles } from "@material-ui/core";

const CustomToggleButton = withStyles({
    root:{
      '&.MuiToggleButton-root.Mui-selected':{
        backgroundColor:'#244a75 !important',
        color:'#fff',
        fontWeight:'bold'
      }
    }
  })(ToggleButton);


export default function CustomToggleBar(props:any) {
  return (
      <>
        < CustomToggleButton />
      </>
  );
}
