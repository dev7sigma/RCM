import React, { useState,  useEffect  } from "react";
import Alert from '@material-ui/lab/Alert';
import Snackbar from '@material-ui/core/Snackbar';


export default function NotificationBar(props:any) {
  const [snackBarSeverity, setSnackBarSeverity] = useState("success" as any);
  const [snackBarMsg, setSnackBarMsg] = useState('');
  const [snackBar, setSnackBar] = useState(false);
  
  const hideSnackBar = () => {
    setSnackBarSeverity("success");
    setSnackBarMsg("");
    setSnackBar(false);
    if(props.onHide){
      props.onHide();
    }
  }
 
  useEffect(() => {
    setSnackBar(props.snackBar);
    setSnackBarSeverity(props.severity);
    setSnackBarMsg(props.message);
   
  }, [props]);
 

  return (
      <>
         <Snackbar open={snackBar} autoHideDuration={3000} onClose={hideSnackBar} anchorOrigin={{ "vertical":'top', "horizontal" : 'center' }}>
          <Alert onClose={hideSnackBar} severity={snackBarSeverity} variant="filled" >
           {snackBarMsg}
          </Alert>
        </Snackbar>
      </>
  );
}
