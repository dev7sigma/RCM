import React, { useMemo, useState } from "react";
import {
  withStyles,
  makeStyles,
  useTheme
} from '@material-ui/core/styles';

import {PatientFormControls} from './PatientFormControls'
// Input components
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import Button from '@material-ui/core/Button';
import { Helmet } from "react-helmet";
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormLabel from '@material-ui/core/FormLabel';
import Grid from '@material-ui/core/Grid';
import ToggleButton from '@material-ui/lab/ToggleButton';
import ToggleButtonGroup from '@material-ui/lab/ToggleButtonGroup';
import clsx from  'clsx';
import RequestApi from '../service/RequestApi';

// components
import PageTitle from "../components/PageTitle";

// constants
import { APP_TITLE, PAGE_TITLE_PATIENT, LOCAL_HOST, API, SCHEMES } from '../utils/constants';
import NotificationBar from "../components/NotificationBar";
const patientUrl = LOCAL_HOST + API.PATIENTS;

const departmentList = [
  {
    key:'Pathology',
    value:'Pathology'
  },
  {
    key:'Oncology',
    value:'Oncology'
  },
  {
    key:'Investigation',
    value:'Investigation'
  }
];

const deptTypeList = departmentList.map((type, index) =>
  <MenuItem key={type.value}  value={type.value}>{type.value}</MenuItem>
);

// define css-in-js
const useStyles = makeStyles((theme) => ({
        root: {
            flex: 1,
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
        },
       
        toggleContainer: {
          margin: theme.spacing(2, 0),
        },
        adduser:{
            width:125,
            float:"right",
            marginBottom:"20px"
        },
        divStyling:{
            margin: "20px 0 0 0",
        },
        form:{
            display:"block"
        },
        margin: {
            margin: theme.spacing(1),
        },
        RadioGroup:{
          '& .MuiFormControlLabel-label':{
            fontSize: "10pt",
            textTransform:'uppercase'
          }
        },
        muiSelect: {
            "& .MuiSelect-outlined": {
              fontSize: "10pt"
            }
          },
          select: {
            "& ul": {
              backgroundColor: "#f7f3f3",
            },
            "& li": {
              fontSize: 12,
            }
          },
          formControl: {
            margin: "0 10px",
            minWidth: 120,
          },
          selectFormControl :{
            margin: "10px 10px 0 10px",
            minWidth: 210,
            "& .MuiFormLabel-filled":{
              margin:"0"
            }
          },
          InputLabel:{
            fontSize:'11pt',
            '& .MuiSelect-selectMenu' : {
              fontSize:'12pt',
            }
          },
          primaryButton:{
            backgroundColor:"#4caf50"
          },
          ml10:{
            marginLeft:"10px"
          },
          hosptialContainer:{
            border:'1px solid #ccc',
            padding:'10px',
            borderRadius:'3px',
            textTransform:'uppercase',
            color:'#007FFF',
            boxShadow: "0 1px 2px hsla(0, 0%, 0%, 0.05), 0 1px 4px hsla(0, 0%, 0%, 0.05), 0 2px 8px hsla(0, 0%, 0%, 0.05)",
            backgroundColor:'#F0F7FF'
          }
}));

const CustomToggleButton = withStyles({
  root:{
    '&.MuiToggleButton-root.Mui-selected':{
      backgroundColor:'#244a75 !important',
      color:'#fff',
      fontWeight:'bold'
    }
  }
})(ToggleButton);

const UsersTextField = withStyles({
    root: {   
      '& label.MuiInputLabel-root': {
        fontSize:'10pt'
      },
      '& .MuiOutlinedInput-root': {
        '&:hover fieldset': {
          fontSize:'9pt'
        },
      },
    },
})(TextField);
   
const CustomSelect =  withStyles((theme) => ({
  root: {
    padding:"10px",
    
  },
}))(Select);

const SelectLabel =  withStyles({
  root: {
    margin:"-10px 0px"
  },
})(InputLabel);

const TPAList = [
    {
        key:'TPA 1',
        value:'TPA 1'
    },
    {
        key:'TPA 2',
        value:'TPA 2'
    },
    {
        key:'TPA 3',
        value:'TPA 3'
    }
]

const TPAMenu = TPAList.map((type, index) =>
    <MenuItem key={type.value} value={type.value}>{type.value}</MenuItem>
);

const InsuranceList = [
    {
        key:'Insurance 1',
        value:'Insurance 1'
    },
    {
        key:'Insurance 2',
        value:'Insurance 2'
    },
    {
        key:'Insurance 3',
        value:'Insurance 3'
    }
];

const InsuranceMenu = InsuranceList.map((type, index) =>
    <MenuItem key={type.value} value={type.value}>{type.value}</MenuItem>
);

const GenderList = [
    {
        key:'Male',
        value:'Male'
    },
    {
        key:'Female',
        value:'Female'
    },
    {
        key:'Third Gender',
        value:'Third Gender'
    }
];

const GenderMenu = GenderList.map((type, index) =>
<MenuItem key={type.value} value={type.value}>{type.value}</MenuItem>
);


export default function Patient(props:any) {
    const classes = useStyles();
    const [selectedDate, setDate] = React.useState(new Date());
    const [selectedScheme, setScheme] = React.useState('');
    const [showDepartment, setShowDepartment] = React.useState(false);
    const [showNameOfCorporte, setCorporate] = React.useState(false);
    const [hospitalName, setHospitalName] = React.useState('CARTIS');
    const [sankbar, setSnakBar] = useState(false);
    const [snackBarSeverity, setSnackBarSeverity] = useState("success" as any);
    const [snackBarMsg, setSnackBarMsg] = useState('');
 
    const {
      handleInputValue,
      formIsValid,
      errors,
      resetValues,
      values,
      setOtherValue,
      setPatientDetails
    } = PatientFormControls();
    

    useMemo(() => {
      if(props.isEditPatient){
        setDate(props.patientDetails.dateOfAdmission);
        setHospitalName(props.patientDetails.hospitalName);
        setPatientDetails(props.patientDetails);
        setScheme(props.patientDetails.scheme);
        setCorporate(props.patientDetails.policyType === 'Corporate' ? true : false);
        setShowDepartment(props.patientDetails.admittedFor === 'ip' ? true : false);
      }
      
    }, [props]);

    const updatePatientDetails = (patientData:any) => {
      let putPatientUrl = `${patientUrl}/${patientData.id}`
      RequestApi.requestData("PUT", putPatientUrl, patientData)
        .then( (data:any) => {
          if(data.id){
            props.onUpdate(data);
          }
      });
    }

    const submitPatient = (patientData:any) => {
      patientData.hospitalName = "CARTIS";
      RequestApi.requestData("POST", patientUrl, patientData)
        .then(data => {
          if(data.status && data.status !== "200"){
            setSnackBarSeverity("error");
            setSnackBarMsg(`Patient's Policy Number already Exists in the system!`);
          }
          else if(data.id){
            setSnackBarSeverity("success")
            setSnackBarMsg(`Patient: ${data.name} Successfully added to the record!`);
          }
          setSnakBar(true);
      });
    }

    const handleFormSubmit = async (e: any) => {
      e.preventDefault();
     
      const isValid = Object.values(errors).every((x) => x === "") && formIsValid();
      console.log("isValid==>",isValid);
      if (isValid) {
        if(!props.isEditPatient){
          await submitPatient(values);
        }
        else{
          await updatePatientDetails(values);
        }
      }
    };

    const handleScheme = (event:any, newScheme:any) => {
      if (newScheme !== null) {
        setScheme(newScheme);
        setOtherValue('scheme', newScheme)
      }
    };

    const handleDateChange = (e: any) => {
      setDate(e.target.value);
      setOtherValue('dateOfAdmission', e.target.value);
    };

    const handlePolicy = (e: any) => {
      console.log("policy==>", e.target.value);
      setCorporate(e.target.value === 'Corporate' ? true : false);
      setOtherValue('policyType', e.target.value)
    };

    const handlRadioOption = (e: any) => {
      setOtherValue(e.target.name, e.target.value);
      setShowDepartment(e.target.value === 'ip' ? true : false);
    };

    const departmentMenu = () => {
     return ( <><FormControl variant="outlined" className={classes.selectFormControl}  key="51" style={{marginTop:'35px'}}>
        <CustomSelect MenuProps={{ classes: { paper: classes.select } }}  className={classes.muiSelect}
          name="ipDeparment"
          value={values.ipDeparment}
          onChange={handleInputValue}
          onBlur={handleInputValue}
        >
          {deptTypeList}
        </CustomSelect>
      </FormControl>
      </>
     )
    }

    const nameField = () => {
      return (
        <>
           <div><UsersTextField
            className={classes.margin}
            label="Corporate Name"
            variant="outlined"
            id="corporateName"
            margin = "dense"
            name="corporateName"
            onChange={handleInputValue}
            onBlur={handleInputValue}
            value={values.corporateName}
          />
          </div>
        </>
      );
    }

    const resetData = () => {
      setSnakBar(false);
      if(snackBarSeverity !== "error"){
        resetValues();
      }
    }
    
    return (
      <>
      <NotificationBar snackBar={sankbar} severity={snackBarSeverity} message={snackBarMsg}  onHide={resetData}></NotificationBar>
      {props.isEditPatient ? '' : <>
      <Helmet>
          <title>{PAGE_TITLE_PATIENT} | {APP_TITLE}</title>
      </Helmet>
      <div className={classes.root}>
          <PageTitle title={PAGE_TITLE_PATIENT} />
      </div> </>
    }
      <form className={classes.form} noValidate>

      <div className={classes.divStyling} key="1">
        <div className={classes.hosptialContainer}>
          <strong>Hospital : {hospitalName} </strong>
        </div>
        <div>
        <Grid container spacing={2}>
          <Grid item sm={12} md={6}>
            <div className={classes.toggleContainer}>
              <ToggleButtonGroup style={{border:'1px solid #ccc'}}
                value={selectedScheme}
                exclusive
                onChange={handleScheme}
                aria-label="Scheme"
              >
                {SCHEMES.map((scheme) => {return (
                  <CustomToggleButton value= {scheme.value} className={ props.isEditPatient && scheme.value === props.patientDetails.scheme ? "Mui-selected" : ""}> {scheme.value} </CustomToggleButton>
                )})}
                
              </ToggleButtonGroup>
            </div>
          </Grid>
        </Grid>
        </div>
        <div>
          <RadioGroup  aria-label="cashType" name="cashType" row className={classes.RadioGroup} value={values.cashType}  onChange={handlRadioOption}>
            <FormControlLabel value="cashless" control={<Radio color="primary" />} label="CASHLESS" />
            <FormControlLabel value="reimbursement" control={<Radio color="primary" />} label="REIMBURSEMENT" />
          </RadioGroup>
        </div>

          <UsersTextField
            className={classes.margin}
            label="Hospital Number"
            variant="outlined"
            id="hospitalId"
            margin = "dense"
            name="hospitalId"
            required
            onChange={handleInputValue}
            onBlur={handleInputValue}
            error={errors['hospitalId']}
            helperText ={errors['hospitalId']}
            value={values.hospitalId}
          />
          <FormControl variant="outlined" className={classes.selectFormControl} key="52">
            <SelectLabel className={classes.InputLabel}>Name of TPA</SelectLabel>
            <CustomSelect MenuProps={{ classes: { paper: classes.select } }}  className={classes.muiSelect}
            onChange={handleInputValue}
                onBlur={handleInputValue}
            label="Name of TPA"
            name="tpaName"
            value={values.tpaName}
            >
            {TPAMenu}
            </CustomSelect>
          </FormControl>
          <FormControl variant="outlined" className={classes.selectFormControl} key="53">
              <SelectLabel className={classes.InputLabel}>Insurance Company</SelectLabel>
              <CustomSelect MenuProps={{ classes: { paper: classes.select } }}  className={classes.muiSelect}
              onChange={handleInputValue}
                  onBlur={handleInputValue}
              label="Insurance Co"
              name="insuranceCompany"
              value={values.insuranceCompany}
              >
              {InsuranceMenu}
              </CustomSelect>
          </FormControl>
    </div>
    <div>
    <UsersTextField
          className={classes.margin}
          label="Card Number"
          variant="outlined"
          id="cardNumber"
          margin = "dense"
          name="cardNumber"
          required
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['cardNumber']}
          helperText ={errors['cardNumber']}
          value={values.cardNumber}
    />
    <UsersTextField
          className={classes.margin}
          label="Policy Number"
          variant="outlined"
          id="policyNumber"
          margin = "dense"
          name="policyNumber"
          required
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['policyNumber']}
          helperText ={errors['policyNumber']}
          value={values.policyNumber}
    />
    </div>
    <div>
    <UsersTextField
          className={classes.margin}
          label="Patient Name"
          variant="outlined"
          id="name"
          margin = "dense"
          name="name"
          required
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['name']}
          helperText ={errors['name']}
          value={values.name}
    />
    <FormControl variant="outlined" className={classes.selectFormControl} key="54">
            <SelectLabel className={classes.InputLabel}>Gender</SelectLabel>
            <CustomSelect MenuProps={{ classes: { paper: classes.select } }}  className={classes.muiSelect}
            onChange={handleInputValue}
                onBlur={handleInputValue}
            label="Geneder"
            name="gender"
            value={values.gender}
            >
            {GenderMenu}
            </CustomSelect>
    </FormControl>
    <UsersTextField
          className={classes.margin}
          label="Mobile"
          variant="outlined"
          id="mobile"
          margin = "dense"
          name="mobile"
          required
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['mobile']}
          helperText ={errors['mobile']}
          value={values.mobile}
    />
    </div>
    <div>
  
      <TextField
        id="date"
        label="Date Admission"
        type="date"
        name="dateOfAdmission"
        value={values.dateOfAdmission}
        defaultValue={selectedDate}
        InputLabelProps={{
          shrink: true,
        }}
        onChange={handleDateChange}
        style={{margin:'20px 0 0 10px'}}
      />
    </div>
    <div>
    <FormControl component="fieldset"  style={{margin:'20px 0 0 10px'}}>
      <FormLabel component="legend">Admitted For</FormLabel>
      <RadioGroup aria-label="Admitted For" name="admittedFor" className={classes.RadioGroup} 
       style={{display:'block'}}  onChange={handlRadioOption}
       value={values.admittedFor}>
        <FormControlLabel value="covid" control={<Radio  color="primary"/>} label="COVID 19" />
        <FormControlLabel value="dialysis" control={<Radio  color="primary"/>} label="DIALYSIS" />
        <FormControlLabel value="ip" control={<Radio  color="primary"/>} label="IP" />
      </RadioGroup>
    </FormControl>
    {showDepartment ? departmentMenu() :''}
    </div>
    <div>
    <FormControl component="fieldset"  style={{margin:'20px 0 0 10px'}}>
      <FormLabel component="legend">Type of Policy</FormLabel>
      <RadioGroup  aria-label="cashtype" name="policyType" row onChange={handlePolicy} className={classes.RadioGroup}  value={values.policyType}>
        <FormControlLabel  value="Individual" control={<Radio color="primary" />} label="Individual" />
        <FormControlLabel  value="Corporate" control={<Radio color="primary" />} label="Corporate" />
      </RadioGroup>
      </FormControl>
      {showNameOfCorporte ? nameField() : ''}
     </div>
     <div className={classes.divStyling}>
        <Button className={clsx(classes.primaryButton, classes.ml10)} variant="contained" 
         disabled={!formIsValid()}
         onClick = {handleFormSubmit}
        color="primary">
          Submit
        </Button>
      </div>
    </form>
        </>
    )
}
