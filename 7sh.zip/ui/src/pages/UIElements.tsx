import React, { FC, ReactElement } from "react";
import { Helmet } from "react-helmet";
import { makeStyles, createStyles, Theme, withStyles } from "@material-ui/core/styles";
import TextField from '@material-ui/core/TextField'
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';

// components
import PageTitle from "../components/PageTitle";

// constants
import { APP_TITLE, PAGE_TITLE_UIELEMENTS } from "../utils/constants";


const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
      width: '25ch',
    },
  },
  select: {
    "& ul": {
        backgroundColor: "#f7f3f3",
    },
    "& li": {
        fontSize: 12,
    },
    '& .MuiInputLabel-animated': {
      marginTop:5,
      fontSize: "11pt"
    }
},
  form:{
      width:"100%"
  },
  TextField:{
      margin:"10px"
  }, formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  InputLabel:{
    fontSize:'10pt',
    padding: "0px 0 0 16px",
    marginTop: "-2px"
  }
}));

const AdminSelect = withStyles({
    root: {
      fontSize: "10pt",
      '& .MuiFormControl-root': {
        padding: "5px 0 0 10px",
        fontSize: '9pt'
      },
      '& .MuiOutlinedInput-input': {
        padding: "25px 0 0 10px"
      },
      '& .MuiListItem-root': {
        fontSize: '9pt'
      },
      
    }
  })(Select);

const UIElements: FC<{}> = (): ReactElement => {
  const classes = useStyles();
  const [age, setAge] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const handleChange = (event:any) => {
    setAge(event.target.value);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleOpen = () => {
    setOpen(true);
  };
  return (
    <>
      <Helmet>
        <title>
          {PAGE_TITLE_UIELEMENTS} | {APP_TITLE}
        </title>
      </Helmet>
      <div className={classes.root}>
        <PageTitle title={PAGE_TITLE_UIELEMENTS} />
      </div>
      <div>
      <form  className={classes.form} noValidate>
          <hr/>
        <label>Inputs</label>
        <TextField
                value=""
                variant="outlined"
                margin="normal"
                required
                fullWidth
                id="username"
                label="label"
                name="username"
                autoComplete="username"
                autoFocus
        />
        <TextField className={classes.TextField} label="Standard" />
        <TextField className={classes.TextField} label="Filled" variant="filled" />
        <TextField className={classes.TextField} label="Outlined" variant="outlined" />
        </form>
        <FormControl className={classes.formControl}>
        <InputLabel className={classes.InputLabel}>User Type</InputLabel>
        <AdminSelect MenuProps={{ classes: { paper: classes.select } }} 
          labelId="demo-controlled-open-select-label"
          open={open}
          onClose={handleClose}
          onOpen={handleOpen}
          value={age}
          onChange={handleChange}
          variant="outlined"
         >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value="Front Office">Front Office</MenuItem>
          <MenuItem value="Back Office">Back Office</MenuItem>
          <MenuItem value="TL">TL</MenuItem>
          <MenuItem value="Admin">Admin</MenuItem>
        </AdminSelect>
      </FormControl>
      </div>
    </>
  );
};

export default UIElements;
