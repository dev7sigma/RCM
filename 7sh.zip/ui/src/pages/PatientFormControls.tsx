import { useState } from "react";

const PostUsersForm = async (
  values: any,
  successCallback: any,
  errorCallback: any
) => {
  if (true) successCallback();
  else errorCallback();
};

const initialFormValues = {
  userId:"",
  hospitalId:"",
  scheme: "",
  cashType: "",
  hospitalName:"",
  tpaName:"",
  insuranceCompany:"",
  cardNumber:"",
  policyNumber:"",
  name:"",
  gender:"",
  mobile:"",
  dateOfAdmission:"",
  admittedFor:"",
  policyType:"",
  corporateName:"",
  ipDeparment:""
};

export const PatientFormControls = () => {
  const [values, setValues] = useState(initialFormValues);
  const [errors, setErrors] = useState({} as any);

  const validate: any = (fieldValues = values) => {
    let temp: any = { ...errors };

    if ("scheme" in fieldValues){
      temp.scheme = fieldValues.scheme ? "" : "Scheme is required.";
    }

    if ("hospitalId" in fieldValues){
      temp.hospitalId = fieldValues.hospitalId ? "" : "Hospital Number is required.";
    }
    
    if ("policyNumber" in fieldValues){
        temp.policyNumber = fieldValues.policyNumber ? "" : "Policy Number is required.";
    }

    if ("dateOfAdmission" in fieldValues) {
        temp.dateOfAdmission = fieldValues.dateOfAdmission ? "" : "Date Of Admission is required.";
    }

    if ("mobile" in fieldValues){
      temp.mobile = fieldValues.mobile ? "" : "Mobile is required.";
    }

    if ("policyType" in fieldValues){
      temp.policyType = fieldValues.policyType ? "" : "policyType is required.";
    }

    if ("cardNumber" in fieldValues){
      temp.cardNumber = fieldValues.cardNumber ? "" : "Card Number is required.";
    }

    setErrors({
      ...temp
    });
  };

  const handleInputValue = (e: any) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value
    });
    validate({ [name]: value });
  };

  const handleError = () => {
    resetValues()
  };

  const resetValues = () => {
    setValues({
      ...initialFormValues,
    });
  }

  const setOtherValue = (name:string, value:string) => {
    setValues({
      ...values,
      [name]: value
    });
  }


  const formIsValid = (fieldValues = values) => {
    console.log("fieldValues==>", fieldValues);
    const isValid =
      fieldValues.hospitalId 
      && fieldValues.dateOfAdmission 
      && fieldValues.scheme 
      && fieldValues.policyNumber
      && fieldValues.policyType
      && fieldValues.mobile
      Object.values(errors).every((x) => x === "");
      console.log("isValid==>", isValid);
    return isValid;
  };

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    const isValid =
      Object.values(errors).every((x) => x === "") && formIsValid();
    if (isValid) {
      await PostUsersForm(values, resetValues, handleError);
    }
  };

  const setPatientDetails = (patientDetails:any) =>{
    setValues({
      ...patientDetails
    });
  }

  return {
    values,
    errors,
    handleInputValue,
    handleFormSubmit,
    formIsValid,
    resetValues,
    setOtherValue,
    setPatientDetails
  };
};

