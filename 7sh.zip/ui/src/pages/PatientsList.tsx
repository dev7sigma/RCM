import React, { FC, ReactElement } from 'react';
import { Helmet } from 'react-helmet';
import { makeStyles, createStyles, Theme, withStyles } from "@material-ui/core/styles";
import { DataGrid } from "@material-ui/data-grid";
import Button from '@material-ui/core/Button';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContentText from '@material-ui/core/DialogContentText';
import Alert from '@material-ui/lab/Alert';
import Snackbar from '@material-ui/core/Snackbar';
import CircularProgress from '@material-ui/core/CircularProgress';
import * as _ from "lodash"; 
// components
import PageTitle from "../components/PageTitle";
import Patient from "./Patient";
import RequestApi from '../service/RequestApi';
import NotificationBar from "../components/NotificationBar";

// constants
import { APP_TITLE, PAGE_TITLE_PATIENTS, API, LOCAL_HOST } from '../utils/constants';
import PatientActionMenu from './PatientActionMenu';
const patientUrl = LOCAL_HOST + API.PATIENTS;
// define css-in-js
const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            flex: 1,
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
        },
        adduser:{
            width:125,
            float:"right",
            marginBottom:"20px"
        },
    })
);

const CustomEditPatientDialog = withStyles({
    root: {
      '& .MuiDialog-paperWidthSm': {
       maxWidth:'875px'
      }
    },
})(Dialog);

const CustomDeletePatientDialog = withStyles({
    root: {
      '& .MuiDialog-paperWidthSm': {
       width:'500px'
      }
    },
})(Dialog);

const initialPatientValues = {
    id:"",
    scheme: "",
    cashtype: "",
    hospitalNumber:"",
    tpaName:"",
    insuranceCompany:"",
    cardNumber:"",
    policyNumber:"",
    name:"",
    gender:"",
    mobile:"",
    dateOfAdmission:"",
    admittedFor:"",
    policyType:""
}

const PatientsList: FC<{}> = (): ReactElement => {
    const classes = useStyles();
    const [addPatient, SetAddPatient] = React.useState(false);
    const columns = [
        {
            field: 'name',
            headerName: 'Name',
            width: 140,
            editable: false,
        },
        {
            field: 'mobile',
            headerName: 'Mobile',
            width: 150,
            editable: false,
        },
        {
            field: 'hospitalId',
            headerName: 'Hospital #',
            width: 150,
            editable: false,
        },
        {
            field: 'cardNumber',
            headerName: 'Card #',
            width: 150,
            editable: false,
        },
        {
            field: 'policyNumber',
            headerName: 'Policy #',
            width: 150,
            editable: false,
        },
        {
            field: 'dateOfAdmission',
            headerName: 'Date',
            width: 150,
            editable: false,
        },
        {
            field: "",
            headerName:"Action",
            sortable: false,
            width: 100,
            filterable: false,
            disableClickEventBubbling: true,
            renderCell: (params:any) => {
            const rowData = params.row;
            return <PatientActionMenu rowData = {rowData} parentCallback = {handleCallback}></PatientActionMenu>;
            }
          }
      ];

      const [updatePatient, setUpdatePatient] = React.useState(false);
      const [deletePatient, setDeletePatient] = React.useState(false);
      const [selectedPatient, setSelectedPatient] = React.useState(initialPatientValues);
      const [sankbar, setSnackBar] = React.useState(false);
      const [snackBarMsg, setSnackBarMsg] = React.useState('');
      const [patientsList, setPatientList] = React.useState([] as any);
      const [showSpinner, setShowSpinner] = React.useState(true);
      const [patientsFlag, setPatientsFlag]  = React.useState(true);
      const [snackBarSeverity, setSnackBarSeverity] = React.useState("success" as any);

      const getPatients = () => {
        RequestApi.requestData("GET", patientUrl, {})
          .then((data: any) => {
            setShowSpinner(false);
            setPatientList(data);
          });
      }

      if(!patientsList.length && patientsFlag){
        setPatientsFlag(false);
        getPatients();
      }

      const resetFlags = () => {
        setUpdatePatient(false);
        setDeletePatient(false);
      }

      const handleClose = () => {
        resetFlags();
      };

      const onUpdatePatient = (patient:any) => {
        const newList:any = [...patientsList];
        if(updatePatient){
            setSnackBarMsg(`Patient: ${patient.name} Successfully updated to the record!`);
            let foundIndex = _.findIndex(newList, {id: patient.id});
            if(foundIndex !== -1){
              newList[foundIndex] = patient;
            }
            setPatientList(newList);
            setUpdatePatient(false);
            setSnackBar(true);
        }
      }

      const hideSnackBar = () => {
        setSnackBar(false);
      }

      const showSnakbar = (sankbar:boolean) => {
        return (
          sankbar ? <Snackbar open={sankbar} autoHideDuration={3000} onClose={hideSnackBar} anchorOrigin={{ "vertical":'top', "horizontal" : 'center' }}>
              <Alert onClose={hideSnackBar} severity="success" variant="filled" >
              {snackBarMsg}
              </Alert>
        </Snackbar> : ''
        );
      }

      const deletePatientAction  = () => {
       console.log("deletePatientAction");
       let deletePatientUrl = `${patientUrl}/${selectedPatient.id}`;
        RequestApi.requestData("DELETE", deletePatientUrl, {})
          .then( (response:any) => {
            setSnackBar(true);
            if(response.status && response.status !== "OK"){
              setSnackBarSeverity("error");
              setSnackBarMsg(`Deletion Failed try again`);
            }
            else{
              setSnackBarSeverity("success");
              setSnackBarMsg(`Patient: ${selectedPatient.name} deleted successfully`);
              let newPatientList = patientsList.filter((patient:any) => {
                return patient['id'] != selectedPatient.id;
              });
              setPatientList(newPatientList);
            }
            handleClose();
        });
      }

      const deletePatientDialog = (
        <>
        <CustomDeletePatientDialog 
              open={deletePatient}
              keepMounted
              onClose={handleClose}
              aria-labelledby="alert-dialog-slide-title"
              aria-describedby="alert-dialog-slide-description"
            >
              <DialogTitle id="alert-dialog-slide-title">Delete Patient</DialogTitle>
              <DialogContent dividers>
                <DialogContentText id="alert-dialog-slide-description">
                   Are you sure to Delete <br/>Patient: {selectedPatient.name}?
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClose} color="primary">
                  CANCEL
                </Button>
                <Button onClick={deletePatientAction} color="primary">
                  YES
                </Button>
              </DialogActions>
            </CustomDeletePatientDialog>
            </>
      );

      const editPatientDialog = (
        <>
            <CustomEditPatientDialog 
                open={updatePatient}
                keepMounted
                onClose={handleClose}
                aria-labelledby="alert-dialog-slide-title"
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle id="alert-dialog-slide-title">Edit Patient</DialogTitle>
                <DialogContent dividers>
                <Patient isEditPatient={updatePatient} patientDetails={selectedPatient} onUpdate={onUpdatePatient} />
                </DialogContent>
                <DialogActions>
                <Button onClick={handleClose} color="primary">
                    CLOSE
                </Button>
                </DialogActions>
            </CustomEditPatientDialog>
            </>
        );

    const handleCallback = (action: string, patientData: any) => {
        console.log('action==>', action);
        console.log("patientData==>", patientData);
        setSelectedPatient(patientData);
        switch (action) {
            case 'EDIT_PATIENT':
                resetFlags();
                setUpdatePatient(true);
                break;
            case 'DELETE_PATIENT':
                resetFlags();
                setDeletePatient(true);
                break;
        }
    }

    const resetData = () => {
      setSnackBar(false);
    }
    
    return (
        <>
            {editPatientDialog}
            {deletePatientDialog}
            { showSnakbar(sankbar)}
            { addPatient ? <><Patient /></> : 
            <>
             <NotificationBar snackBar={sankbar} severity={snackBarSeverity} message={snackBarMsg}  onHide={resetData}></NotificationBar>
            <Helmet>
                <title>{PAGE_TITLE_PATIENTS} | {APP_TITLE}</title>
            </Helmet>
            <div className={classes.root}>
                <PageTitle title={PAGE_TITLE_PATIENTS} />
            </div>
            <div>
                  <Button variant="contained" color="primary" size="small" className={classes.adduser}  onClick={() => SetAddPatient(true)}>
                     Add Patient
                  </Button>
              </div>
              {showSpinner ?  <CircularProgress disableShrink /> : 
              <div style={{ display:'flex', height: 425, width: '100%', clear:'both' }}>
                <DataGrid rows={patientsList} columns={columns} pageSize={5}
                    disableSelectionOnClick
                />
              </div>
              }
            
        </>
            }
        </>
        
    )
}

export default PatientsList;