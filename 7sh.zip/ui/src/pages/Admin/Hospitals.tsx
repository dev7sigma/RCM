import React, { useMemo, useState, useEffect } from "react";
import {
  withStyles,
  makeStyles,
  useTheme
} from '@material-ui/core/styles';
import {
  Link
} from "react-router-dom";
import Chip from '@material-ui/core/Chip';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import Button from '@material-ui/core/Button';
import clsx from  'clsx';
import {HospitalFormControls} from './HospitalFormControls'
import { Helmet } from "react-helmet";
import PageTitle from "../../components/PageTitle";
import NotificationBar from '../../components/NotificationBar';

import LocalHospital from '@material-ui/icons/LocalHospital';
import Input from '@material-ui/core/Input';
import {API, APP_TITLE, PAGE_TITLE_ADMIN_HOSPITAL, LOCAL_HOST, SCHEMES } from "../../utils/constants";
import RequestApi from '../../service/RequestApi';
import { useSelector, useDispatch } from "react-redux";
import { setSchemes } from '../../redux/actions/schemeActions';
const schemesUrl = LOCAL_HOST + API.SCHEMES;

const hospitalTypes = [
    {
      key:'Super Speciality',
      value:'Super Speciality'
    },
    {
      key:'Multi Speciality',
      value:'Multi Speciality'
    },
    {
      key:'Speciality',
      value:'Speciality'
    }
];
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};
function getStyles(name:any, scheme:any, theme:any) {
  return {
    fontSize:"10pt",
    fontWeight:
    scheme.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}
// const schemes = SCHEMES;

const hospitalTypeList = hospitalTypes.map((type, index) =>
  <MenuItem key={type.value}  value={type.value}>{type.value}</MenuItem>
);

const UsersTextField = withStyles({
  root: {   
    width:"250px",
    margin:"8px 12px",
    '& label.MuiInputLabel-root': {
      fontSize:'10pt'
    },
    '& .MuiOutlinedInput-root': {
      '&:hover fieldset': {
        fontSize:'9pt'
      },
    },
  },
})(TextField);

const CustomSelect =  withStyles((theme) => ({
  root: {
    padding:"10px",
  },
}))(Select);

const EmailTextField = withStyles({
  root: {
    width:"250px",
    margin:"8px 9px",
    '& label.MuiInputLabel-root': {
      fontSize:'10pt'
    },
    '& .MuiOutlinedInput-root': {
      '&:hover fieldset': {
        fontSize:'9pt'
      },
    },
  },
})(TextField);

const SelectLabel =  withStyles({
  root: {
    margin:"-10px 0px"
  },
})(InputLabel);

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  muiSelect: {
    "& .MuiSelect-outlined": {
      fontSize: "10pt"
    }
  },
  select: {
    "& ul": {
      backgroundColor: "#f7f3f3",
    },
    "& li": {
      fontSize: 12,
    }
  },
  form:{
    display:"block"
  },
  margin: {
    margin: theme.spacing(1),
  },
  formControl: {
    margin: "0 10px",
    minWidth: 120,
  },
  selectFormControl :{
    width:"250px",
    margin:"8px 9px",
    "& .MuiFormLabel-filled":{
      margin:"0"
    }
  },
  InputLabel:{
    fontSize:'11pt',
    '& .MuiSelect-selectMenu' : {
      fontSize:'12pt',
    }
  },
  divStyling:{
    margin: "20px 0 0 0",
  },
  primaryButton:{
    backgroundColor:"#4caf50"
  },
  ml10:{
    marginLeft:"10px"
  },
  fontSize:{
    fontSize:'10pt'
  },chips: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  chip: {
    margin: 2,
  }
}));




export default function Hospitals(props:any) {
  const classes = useStyles();
  const theme = useTheme();

  const {
    handleInputValue,
    formIsValid,
    errors,
    resetValues,
    values,
    setHospitalDetails,
    handleMultiSelect
  } = HospitalFormControls();

  const submitUserUrl = LOCAL_HOST + API.submitHospital;
  const updateHospital = LOCAL_HOST + API.HOSPITALS_URL;
  const [sankbar, setSnakBar] = useState(false);
  const [snackBarMsg, setSnackBarMsg] = useState('');
  const [stopRender, setStopRender] = useState(false);
  const [show, setShow] = useState(true);
  const [hospitalType, setHospitalType]  = useState('');
  const [scheme, setScheme] = useState([]);
  const [snackBarSeverity, setSnackBarSeverity] = useState("success" as any);

  const schemesList = useSelector((state:any) => state.allSchemes.schemes);
  const dispatch = useDispatch();

  const getSchemes = async () => {
    RequestApi.requestData("GET", schemesUrl, {})
    .then( list => {
      dispatch(setSchemes(list));
    });
  }

  useEffect(() => {
    getSchemes();
  }, []);

  const handleSchemesChange = (e:any) => {
    setScheme(e.target.value);
    handleMultiSelect(e);
  };

  
  useMemo(() => {
    if(props.isEditHospital){
      console.log("hospitalDetails==>", props.hospitalDetails);
      let scheme:any = props.hospitalDetails.schemas ? props.hospitalDetails.schemas.split(",") : [];
      setScheme(scheme);
      setHospitalDetails(props.hospitalDetails);
      setHospitalType(props.hospitalDetails.type);
      setShow(false);
    }
    else if(!props.isEditHospital){
      setShow(true);
    }
  }, [props]);

  const resetData = () => {
    setSnakBar(false);
    setSnackBarSeverity("success");
    if(snackBarSeverity !== "error"){
      resetValues();
      setScheme([]);
    }
  }

 const updateHospitalDetails = (hospitalData:any) => {
    let putHospitalUrl = `${updateHospital}/${hospitalData.id}`;
    RequestApi.requestData("PUT", putHospitalUrl, hospitalData)
      .then(data => {
        if(data.id){
          props.onUpdate(data);
        }
    });
  }

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    const isValid = Object.values(errors).every((x) => x === "") && formIsValid();
    if (isValid) {
      if(!props.isEditHospital){
        await submitHospital(values);
      }
      else{
        await updateHospitalDetails(values);
      }
    }
  };

  const handleHospitalType = (e:any) => {
    setHospitalType(e.target.value);
    handleInputValue(e);
  }

  const submitHospital = (hospitalData:any) => {
    RequestApi.requestData("POST", submitUserUrl, hospitalData)
      .then(data => {
        if(data.status && data.status !== "200"){
          setSnackBarSeverity("error");
          setSnackBarMsg(`Hospital's Email and Registration Number already Exists in the system!`);
          setSnakBar(true);
        }
        else if(data.id){
          setSnackBarMsg(`Hospital: ${data.name} Successfully added to the record!`);
          setSnakBar(true);
        }
    });
  }

  return (
    <>
     <NotificationBar snackBar={sankbar} severity={snackBarSeverity} message={snackBarMsg} onHide={resetData}></NotificationBar>
     { show ? 
     <>
     <Link to="/admin/hospitals" style={{ fontSize:'10pt', textDecoration: 'none'}}>
      <Chip
        style={{ cursor:'pointer', marginBottom:'10px' }}
        icon={<LocalHospital />}
        label="Hospitals"
      />
      </Link>
      <Helmet>
        <title>
            {PAGE_TITLE_ADMIN_HOSPITAL} | {APP_TITLE}
        </title>
      </Helmet>
      <div className={classes.root}>
          <PageTitle title={PAGE_TITLE_ADMIN_HOSPITAL} />
      </div>
      </>
      : ""}
      <form className={classes.form} noValidate>
      <div className={classes.divStyling} key="1">
        <UsersTextField
          className={classes.margin}
          label="Hospital Name"
          variant="outlined"
          id="name"
          margin = "dense"
          name="name"
          required
          value={values.name}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['name']}
          helperText ={errors['name']}
          key="2"
          />

        <UsersTextField
          className={classes.margin}
          label="Registration No"
          variant="outlined"
          id="regNo"
          margin = "dense"
          name="regNo"
          required
          value={values.regNo}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['regNo']}
          helperText ={errors['regNo']}
          key="22"
          />

        <EmailTextField
          label="Email"
          variant="outlined"
          id="email"
          margin = "dense"
          name="email"
          required
          value={values.email}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['email']}
          helperText ={errors['email']}
          key="3"
        />
        </div>
        <div>
        <UsersTextField
          className={classes.margin}
          label="Place"
          variant="outlined"
          id="place"
          margin = "dense"
          name="place"
          value={values.place}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['place']}
          helperText ={errors['place']}
          key="4"
          />

        <UsersTextField
          className={classes.margin}
          label="Locality"
          variant="outlined"
          id="locality"
          margin = "dense"
          name="locality"
          value={values.locality}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['locality']}
          helperText ={errors['locality']}
          />

        <UsersTextField
          className={classes.margin}
          label="City"
          variant="outlined"
          id="city"
          margin = "dense"
          name="city"
          value={values.city}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['city']}
          helperText ={errors['city']}
          required
          />
</div><div>
<UsersTextField
          className={classes.margin}
          label="District"
          variant="outlined"
          id="district"
          margin = "dense"
          name="district"
          required
          value={values.district}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['district']}
          helperText ={errors['district']}
          key="441"
          />

<UsersTextField
          className={classes.margin}
          label="State"
          variant="outlined"
          id="state"
          margin = "dense"
          name="state"
          required
          value={values.state}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['state']}
          helperText ={errors['state']}
          key="442"
          />

<UsersTextField
          className={classes.margin}
          label="Pincode"
          variant="outlined"
          id="pinCode"
          margin = "dense"
          name="pinCode"
          required
          value={values.pinCode}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['pinCode']}
          helperText ={errors['pinCode']}
          key="44"
          />
</div><div>
<UsersTextField
          className={classes.margin}
          label="Web Site URL"
          variant="outlined"
          id="webSite"
          margin = "dense"
          name="webSite"
          value={values.webSite}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['webSite']}
          helperText ={errors['webSite']}
          key="443"
          />

<FormControl variant="outlined" className={classes.selectFormControl}  key="51">
        <SelectLabel className={classes.InputLabel}>Hospital Type</SelectLabel>
        <CustomSelect MenuProps={{ classes: { paper: classes.select } }}  className={classes.muiSelect}
          onChange={handleHospitalType}
          label="Hospital Type"
          name="type"
          value={hospitalType}
        >
          {hospitalTypeList}
        </CustomSelect>
      </FormControl>

<UsersTextField
          className={classes.margin}
          label="Hospital Fax"
          variant="outlined"
          id="fax"
          margin = "dense"
          name="fax"
          value={values.fax}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['fax']}
          helperText ={errors['fax']}
          key="445"
          />
     
      </div>
      <div>
      <UsersTextField
          className={classes.margin}
          label="Hospital Phone"
          variant="outlined"
          id="phone"
          margin = "dense"
          name="phone"
          required
          value={values.phone}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['phone']}
          helperText ={errors['phone']}
          key="446"
          />

      <FormControl className={classes.selectFormControl}>
        <InputLabel id="demo-mutiple-chip-label" className={classes.fontSize}>Scheme</InputLabel>
        <Select
          labelId="demo-mutiple-chip-label"
          id="schemas"
          multiple
          name="schemas"
          value={scheme}
          onChange={handleSchemesChange}
          input={<Input id="select-multiple-chip" />}
          renderValue={(selected:any) => (
            <div className={classes.chips}>
              {selected.map((value:any) => (
                <Chip key={value} label={value} className={classes.chip} />
              ))}
            </div>
          )}
          MenuProps={MenuProps}
        >
          {schemesList.map((scheme:any) => (
            <MenuItem  key={scheme.id} value={scheme.name} style={getStyles(scheme, scheme.name, theme)}>
              {scheme.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      </div>

      <div className={classes.divStyling}>
        <Button className={clsx(classes.primaryButton, classes.ml10)} variant="contained" 
         disabled={!formIsValid()}
         onClick = {handleFormSubmit}
         color="primary">
          {show ? 'Submit' : "Save" }
        </Button>
      </div>
        
      </form>
    </>
  );
}


