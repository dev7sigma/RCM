import React, { FC, ReactElement, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";
import {
    DataGrid,
} from "@material-ui/data-grid";
import Button from '@material-ui/core/Button';
import DeleteIcon from '@material-ui/icons/Delete';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContentText from '@material-ui/core/DialogContentText';
import CircularProgress from '@material-ui/core/CircularProgress';
import TextField from '@material-ui/core/TextField';
// components
import PageTitle from "../../components/PageTitle";
import RequestApi from '../../service/RequestApi';
import BulkUpload from './BulkUpload';
import NotificationBar from '../../components/NotificationBar';
import { useSelector, useDispatch } from "react-redux";
import { setSchemes } from '../../redux/actions/schemeActions';

// constants
import { APP_TITLE, PAGE_TITLE_ADMIN_SCHEMES, API, LOCAL_HOST } from '../../utils/constants';
const schemesUrl = LOCAL_HOST + API.SCHEMES;

const SchemeIcon = <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAgUlEQVRIie2T0Q2AIAxEW+MYDsM0rskwuMf5Qw02QtACidH32cK1VwrR22EdAACTIPNJc7KIfRAAHnZ8Ttw1EBdcr+6FwwUnBUzrqZF1Hbum4q/l/e4O5lJSdyNzzcWv6O7g/QWKb1CabS3DHWxEtNz9C+p8SHPawRqLPCVEjZ96dnfGESrX9xtDAAAAAElFTkSuQmCC"/>;

// define css-in-js
const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            flex: 1,
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
        },
        dialogContent:{
            width:"600px"
        },
        textField:{
            width:300
        }
    })
);


const SchemesList: FC<{}> = (): ReactElement => {
    const classes = useStyles();
    const [sankbar, setSnakBar] = React.useState(false);
    const [snackBarMsg, setSnackBarMsg] = React.useState('');
    const [deleteScheme, setDeleteScheme]  = React.useState(false);
    const [addSchemeFlag, setAddScheme]  = React.useState(false);
    const [selectedScheme, setSchemeValue] = React.useState({name:"", id:0});
    const [newScheme, setSchemeName]  = React.useState('');
    const [showSpinner, setShowSpinner] = React.useState(true);
    
    const schemeList = useSelector((state:any) => state.allSchemes.schemes);
    const dispatch = useDispatch();
  
    const getSchemes = async () => {
      RequestApi.requestData("GET", schemesUrl, {})
      .then( list => {
        setShowSpinner(false);
        dispatch(setSchemes(list));
        console.log("schemeList==>", schemeList);
      });
    }
    useEffect(() => {
      getSchemes();
    }, []);
   
    const removeScheme = (scheme:any) => {
        setSchemeValue(scheme);
        resetFlags();
        setDeleteScheme(true);
        console.log("remove scheme::", scheme);
        
    }
    
    const deleteSchemeAction = () => {
      let deleteUserUrl = schemesUrl +'/'+ selectedScheme.id;
      RequestApi.requestData("DELETE", deleteUserUrl, {})
        .then( (response) => {
         deleteSuccess();
      }).catch(function(e){
        console.log("error==>", e);
      });
    }
       
    //Sample Data
    const columns = [
    {
        field: 'name',
        headerName: 'Scheme',
        width: 500,
        editable: false,
    },
    
    {
        field: "",
        headerName:"Action",
        sortable: false,
        filterable: false,
        disableClickEventBubbling: true,
        renderCell: (params:any) => {
          const rowData = params.row;
          return (<DeleteIcon style={{fill: "#423b3b", cursor:'pointer'}} onClick = {() => removeScheme(rowData)}/>);
        }
      }
  ];
  
  const handleClose = () => {
    resetFlags();
  };
  
  const deleteSchemeDialog = (
    <>
    <Dialog 
          open={deleteScheme}
          keepMounted
          onClose={handleClose}
          aria-labelledby="alert-dialog-slide-title"
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle id="alert-dialog-slide-title">Delete Hospital</DialogTitle>
          <DialogContent dividers  className={classes.dialogContent}>
            <DialogContentText id="alert-dialog-slide-description">
               Are you sure to Delete Scheme
               <br/> <b> {selectedScheme.name}?</b>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              CANCEL
            </Button>
            <Button onClick={deleteSchemeAction} color="primary">
              YES
            </Button>
          </DialogActions>
        </Dialog>
        </>
  );

  const saveScheme = (e:any) => {
      setSchemeName(e.target.value);
  }

  const addSchemeDialog = (
    <>
    <Dialog 
          open={addSchemeFlag}
          keepMounted
          onClose={handleClose}
          aria-labelledby="alert-dialog-slide-title"
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle id="alert-dialog-slide-title">Add Scheme</DialogTitle>
          <DialogContent dividers  className={classes.dialogContent}>
            <DialogContentText id="alert-dialog-slide-description">
              <TextField 
               label="Scheme"
               id="SchemeName"
               margin = "dense"
               name="name"
               value={newScheme}
            className={classes.textField}
            onChange={saveScheme}
              ></TextField>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              CLOSE
            </Button>
            <Button onClick={() => {addSchemeAction()}} color="primary">
              ADD
            </Button>
          </DialogActions>
        </Dialog>
        </>
  );

  const openAddScheme = () => {
    resetFlags();
    setAddScheme(true);
  }

  const resetFlags = () => {
    setDeleteScheme(false);
    setSnakBar(false);
    setAddScheme(false);
    setSchemeName('');
  }

  const deleteSuccess = () => {
    resetFlags();
    setDeleteScheme(false);
    setSnakBar(true);
    setSnackBarMsg(`Scheme: ${selectedScheme.name} Successfully deleted!`);
    let newSchemeListList = schemeList.filter((dep:any) => {
      return dep['id'] !== selectedScheme.id
    });
    dispatch(setSchemes(newSchemeListList));
  }


  const addSchemeAction = () => {
    RequestApi.requestData("POST", schemesUrl, {name:newScheme})
    .then( (data:any) => {
      if(data.id){
        setSnakBar(true);
        const newList = [...schemeList];
        newList.push(data);
        dispatch(setSchemes(newList));
        setSnackBarMsg(`Scheme: ${newScheme} Successfully Added!`);
        resetFlags();
        setAddScheme(true);
      }
    }).catch(function(e){
      console.log("e==>", e);
     });
  }

    return (
        <>
            {deleteSchemeDialog}
            {addSchemeDialog}
            <NotificationBar snackBar={sankbar} severity="success" message={snackBarMsg}></NotificationBar>
            <Helmet>
                <title>{PAGE_TITLE_ADMIN_SCHEMES} | {APP_TITLE}</title>
            </Helmet>
            <div className={classes.root}>
                <PageTitle title={PAGE_TITLE_ADMIN_SCHEMES} />
            </div>
            <div>
                <div style={{marginTop:"50px", width:"60%", textAlign:"right"}}>
                <BulkUpload moduleName="Schemes"></BulkUpload>
                    <Button variant="contained" color="primary" size="small"  startIcon={SchemeIcon}  onClick={() => openAddScheme()} >
                        Add Scheme
                    </Button>
                </div>

                {showSpinner ?  <CircularProgress disableShrink /> : 
                <div style={{ display:'flex', height: 600, width: '60%', clear:'both', margin:"20px 20px 20px 0" }}>
                  <DataGrid
                      rows={schemeList}
                      columns={columns}
                      disableSelectionOnClick
                  />
                </div>
              }
          </div>
        </>
    )
}

export default SchemesList;