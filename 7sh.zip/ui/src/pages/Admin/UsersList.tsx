import React, { FC, ReactElement, ChangeEvent, useState } from "react";
import { Helmet } from "react-helmet";
import { makeStyles, createStyles, Theme, withStyles } from "@material-ui/core/styles";
import clsx from  'clsx';
import PageTitle from "../../components/PageTitle";
import { DataGrid } from "@material-ui/data-grid";
import Button from '@material-ui/core/Button';
import User from './User';
import UserActionMenu from './UserActionMenu';
import Link from '@material-ui/core/Link';

import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';

import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import DialogContentText from '@material-ui/core/DialogContentText';
import NotificationBar from '../../components/NotificationBar';
import Grid from '@material-ui/core/Grid';
import Avatar from '@material-ui/core/Avatar';
import Paper from '@material-ui/core/Paper';
import DeleteIcon from '@material-ui/icons/Delete';

import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';
import CircularProgress from '@material-ui/core/CircularProgress';
import * as _ from "lodash"; 
import RequestApi from '../../service/RequestApi';

// constants
import { APP_TITLE, PAGE_TITLE_USERS_LIST, API, LOCAL_HOST } from "../../utils/constants";
import BulkUpload from "./BulkUpload";
import ScrimBackDrop from "../../components/ScrimBackDrop";
const getAllUsers = LOCAL_HOST + API.getAllUsers;
const searchHospital =  LOCAL_HOST + API.searchHospital;
const mapUserHospital = LOCAL_HOST + API.USER_HOSPITAL_MAP;
const unMapUserHospital = LOCAL_HOST + API.USER_HOSPITAL_UMMAP;

// define css-in-js
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flex: 1,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
    },
    adduser:{
        width:125,
        float:"right",
        marginBottom:"20px"
    },
    adduserLink:{
        color:"#fff",
    },
    dialogContent:{
      width:"600px"
    },
    editUserDC:{
      width:"875px"
    },
    paper: {
      maxWidth: 450,
      margin: '10px',
      padding: theme.spacing(2),
    },
    input: {
      marginLeft: theme.spacing(1),
      flex: 1,
    },
    iconButton: {
      padding: 10,
    },
    search: {
     width:300
    },
    closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500],
    }
  })
);

const AddUserIcon = <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAABMUlEQVRIie2UsUoDQRRF7wrJYmlpdG1TCoKFvYid/2HUQvCPbBICNjYWlhoDISiInX+gQjZ2Fscib2GZ7M667oCNBx4DM+/d+2Z2dqR/QgAkwBBILa6Abkjxd5b5AJIQBsMC8YxBCIPUYzCrql9p6h/C4NazdvPzXkoAuvZBXd6AzcYGZpIAA2Bm0Q8m/mcAMXAKPACfFiPgBGg3Fd8AHj3Xdwp0JCmqENqVdCRpW1IriqJDIJY0tjkfU0l7RaKrwAXw6nR1butnbru5Wpde0dafSra9YznjGgYj1+C6RBxgzXLmrnDBKWSk7p+87znTr6zek7OEaxB7crdsfMkmyo4oV/Nc57E7sPGyRk2d3AVAm8U9r2ICtGobmEmnwmQCrP9K3NlJD7i3mzUH7oDjfOffBzg0iSI9LLwAAAAASUVORK5CYII="/>;

const userDetails:any = {
  id: 0,
  schemas: "",
  adminType: "",
  email: "",
  mobile: "",
  name: "hospital name",
  type: "",
  hospitals:[],
}

const CustomEditUserDialog = withStyles({
  root: {
    '& .MuiDialog-paperWidthSm': {
     maxWidth:'875px'
    }
  },
})(Dialog);

const UsersList: FC<{}> = (): ReactElement => {
  const classes = useStyles();
  const [addHospital, setAddHospital] = useState(false);
  const [editUser, setEditUser] = useState(false);
  const [deleteUser, setDeleteUser] = useState(false);
  const [selectedUser, setSelectedUser] = useState(userDetails);
  const [searchVal, setSearchValue] = useState('');
  const [sankbar, setSnakBar] = useState(false);
  const [snackBarMsg, setSnackBarMsg] = useState('');
  const [showExistingHospital, setShowExistingHospital] = useState(false);
  const [showSearchHospital, setShowSearchHospital] = useState(true);
  const [showSpinner, setShowSpinner] = useState(true);
  const [usersList, setUsersList] = useState([] as any);
  const [getUsersFlag, setUserFlag]  = useState(true);
  const [hospitalRows, setHospitalRows] = useState([]);
  const [snackBarSeverity, setSnackBarSeverity] =  useState("success" as any);

  //Sample Data
  const columns = [
    {
        field: 'name',
        headerName: 'Name',
        width: 140,
        editable: false,
    },
    {
        field: 'email',
        headerName: 'Email',
        width: 200,
        editable: false,
    },
    {
        field: 'mobile',
        headerName: 'Phone',
        width: 150,
        editable: false,
    },
    {
        field: 'type',
        headerName: 'User Type',
        width: 150,
        editable: false,
    },
    {
        field: 'adminType',
        headerName: 'Level',
        width: 150,
        editable: false,
    },
    {
        field: 'schemas',
        headerName: 'schemas',
        width: 150,
        editable: false,
    },
    {
        field: "",
        headerName:"Action",
        sortable: false,
        width: 100,
        filterable: false,
        disableClickEventBubbling: true,
        renderCell: (params:any) => {
          const rowData = params.row;
          return <UserActionMenu rowData = {rowData} parentCallback = {handleCallback}></UserActionMenu>;
        }
      }
  ];

  const hospitalCols = [
    {
        field: 'name',
        headerName: 'Hospital Name',
        width: 140,
        editable: false,
    },
    {
        field: 'hospitalAddress',
        headerName: 'Address',
        width: 200,
        editable: false,
    },
    {
        field: "",
        headerName:"Action",
        sortable: false,
        width: 150,
        filterable: false,
        disableClickEventBubbling: true,
        renderCell: (params:any) => {
          return ( <><Button variant="contained" color="primary" size="small" style={{fontSize:'8pt'}} onClick={() => mapHospital(params.row)}>
           Add Hospital
        </Button></> )
        }
      }
  ];

  const mapHospital = (hospitalData:any) => {
    RequestApi.requestData("POST", mapUserHospital,  {userId:selectedUser.id, hospitalId:hospitalData.id})
        .then( (data:any) => {
          console.log("data==>", data);
          setSnackBarMsg(`Hospital: ${hospitalData.name} Successfully Mapped to User ${selectedUser.name}`);
          setSnakBar(true);
          const newList:any = [...usersList];
          let foundIndex = _.findIndex(newList, {id: data.id});
          if(foundIndex !== -1){
            newList[foundIndex] = data;
          }
          setSelectedUser(data);
          setUsersList(newList);
          setShowExistingHospital(true);
    });
  }

  const handleCallback = (action:string, userData:any) => {
    console.log('action==>', action);
    console.log("userData==>", userData);
    setSelectedUser(userData);
    if(userData.hospitals.length){
      setShowExistingHospital(true);
    }
    switch(action){
        case 'ADD_HOSPITAL':
          setAddHospital(true);
          setDeleteUser(false);
          setEditUser(false);
        break;
        case 'EDIT_USER':
          setEditUser(true);
          setAddHospital(false);
          setDeleteUser(false);
        break;
        case 'DELETE_USER':
          setDeleteUser(true);
          setEditUser(false);
          setAddHospital(false);
        break;
    }
  }

  const getUsers = () => {
    RequestApi.requestData("GET", `${getAllUsers}?pageSize=100`, {})
      .then((data: any) => {
        setShowSpinner(false);
        setUsersList(data);
      });
  }

  const onSearchTextChange = (event: ChangeEvent<HTMLInputElement>) => {
    setSearchValue(event.target.value);
      
    if(searchVal.length > 2){
      RequestApi.requestData("POST", searchHospital, {key:'name', value:searchVal})
        .then( (data:any) => {
          console.log("data==>", data);
          setHospitalRows(data);
        });
    }
  }

  if(!usersList.length && getUsersFlag){
    setUserFlag(false);
    getUsers();
  }
  
  const deleteUserAction = () => {
    let deleteUserUrl = LOCAL_HOST + API.searchUsers + selectedUser.id;
    RequestApi.requestData("DELETE", deleteUserUrl, {})
      .then( (id:any) => {
        console.log("delete==>", id);
        setDeleteUser(false);
        setSnakBar(true);
        setSnackBarMsg("User deleted Successfully!");
        let newUserList = usersList.filter((user:any) => {
          return user['id'] != selectedUser.id;
        });
        setUsersList(newUserList);
    });
  }
 
  const handleClose = () => {
    setEditUser(false);
    setAddHospital(false);
    setDeleteUser(false);
  };

  const resetData = () => {
    setSnakBar(false);
  }

  const unMapHospital = (hospital:any) => {
    RequestApi.requestData("POST", unMapUserHospital, {userId:selectedUser.id, hospitalId:hospital.id})
        .then( (data:any) => {
          _.remove(selectedUser.hospitals, {id:hospital.id});
          setShowExistingHospital(true);
          setSnakBar(true);
          setSnackBarMsg('Hospital mapping successfully removed for the user!')
    });
  }

  const getMappedHospitals = () => {
    console.log("selectedUser.hospitals==>", selectedUser.hospitals);
    let mappedHospitals = null;
    if (selectedUser.hospitals.length) {
      mappedHospitals = selectedUser.hospitals.map((hospital: any) => {
        return (<><Paper className={classes.paper}>
          <Grid container wrap="nowrap" spacing={2}>
          <Grid item>
            <Avatar>{hospital.name.charAt(0).toUpperCase()}</Avatar>
          </Grid>
          <Grid item xs zeroMinWidth>
            <Typography noWrap style={{ display: 'inline-block', width: '85%', textTransform: 'capitalize', paddingTop: '5px' }}>
              {hospital.name}
            </Typography>
            <div style={{ display: 'inline-block', verticalAlign: 'middle', width: '50px', textAlign: 'right' }} title="Delete Hospital for user">
              <DeleteIcon style={{ fill: "#b93333", cursor: 'pointer' }} onClick={() => unMapHospital(hospital)} /></div>
          </Grid>
        </Grid></Paper></>)
      })
    }
    return mappedHospitals;
  }

const AddUpdateHopsitalDialog = (
<Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={addHospital} >
<DialogTitle>
  Add/Modify Hospital
</DialogTitle>
<DialogContent dividers className={classes.dialogContent}>

{ showExistingHospital ? <>
<Typography variant="subtitle2" gutterBottom>
  <strong>Mapped Hospital(s)</strong>
</Typography>
{getMappedHospitals()}
 </> : null}

<Typography gutterBottom>
<Typography variant="subtitle2" gutterBottom>
  <strong>Search Hospital for Mapping </strong>
</Typography>
  <Paper component="form" className={clsx(classes.root, classes.search)}>
      <InputBase
        className={classes.input}
        placeholder="Search Hospital to map"
        inputProps={{ 'aria-label': 'Search Hospital to map' }}
        onChange = {onSearchTextChange}
      />
      <IconButton type="button" className={classes.iconButton} aria-label="search">
        <SearchIcon />
      </IconButton>
    </Paper>
    <div style={{ display:'flex', height: 250, width: '100%', clear:'both', marginTop:"20px" }}>
         <DataGrid rows={hospitalRows} columns={hospitalCols} pageSize={5} disableSelectionOnClick    />
     </div>
</Typography>
  
</DialogContent>
<DialogActions>
  <Button autoFocus onClick={handleClose} color="primary">
    CLOSE
  </Button>
</DialogActions>
</Dialog>
);

const handleUserEditSuccess = (updatedUserData:any) => {
  console.log("updatedUserData==>", updatedUserData);
  setSnackBarMsg(`User: ${updatedUserData.name} Successfully updated to the record!`);
  let newUserList:any  = usersList.map((user:any) => {
    if(user['id'] === updatedUserData.id){
     return updatedUserData;
    }
    else return user;
  });
  setUsersList(newUserList);
  setSnakBar(true);
  setEditUser(false);
}

const editUserDialog = (
  <>
  <CustomEditUserDialog 
        open={editUser}
        keepMounted
        onClose={handleClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">Edit User</DialogTitle>
        <DialogContent dividers className={classes.editUserDC}>
          <User isEditUser={editUser} userDetails={selectedUser} successCallback={handleUserEditSuccess}/>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            CLOSE
          </Button>
        </DialogActions>
      </CustomEditUserDialog>
      </>
)

const onUploadFile = (data:any) => {
  setShowBackDrop(false);
  if(data.status && data.status !== 200){
    setSnackBarSeverity("error");
    setSnackBarMsg(data.message);
    setSnakBar(true);
  }
  else{
    getUsers();
    handleClose();
    setSnackBarSeverity("success");
    setSnackBarMsg("Users uploaded Successfully !");
    setSnakBar(true);
  }
}

const deleteUserDialog = (
  <>
  <Dialog 
        open={deleteUser}
        keepMounted
        onClose={handleClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">Delete User</DialogTitle>
        <DialogContent dividers>
          <DialogContentText id="alert-dialog-slide-description">
             Are you sure to Delete user {selectedUser.name}?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            CANCEL
          </Button>
          <Button onClick={deleteUserAction} color="primary">
            YES
          </Button>
        </DialogActions>
      </Dialog>
      </>
);

  const [showBackDrop, setShowBackDrop] = useState(false);

  const setBackDrop = (flagVal:boolean) => {
    setShowBackDrop(flagVal);
  }

  return (
          <>
          <NotificationBar snackBar={sankbar}  severity={snackBarSeverity} message={snackBarMsg}  onHide={resetData}></NotificationBar>
          { showBackDrop ? <ScrimBackDrop></ScrimBackDrop> : null }
          {AddUpdateHopsitalDialog}
          {deleteUserDialog}
          {editUserDialog}
          <Helmet>
              <title>
                  {PAGE_TITLE_USERS_LIST} | {APP_TITLE}
              </title>
          </Helmet>
          <div className={classes.root}>
              <PageTitle title={PAGE_TITLE_USERS_LIST} />
          </div>
          {process.env.NODE_ENV}
          <div>
              <div style={{display:"block", float:'right'}}>
                  <BulkUpload moduleName="Users" onUpload={onUploadFile} showBackDrop={setBackDrop}></BulkUpload>
                  <Button variant="contained" color="primary" size="small" className={classes.adduser} startIcon={AddUserIcon}>
                     <Link href="/admin/user" className={classes.adduserLink}> Add User</Link>
                  </Button>
              </div>
              <div style={{clear:'both'}}></div>
          </div>
          {showSpinner ?  <CircularProgress disableShrink /> : 
          <div style={{ display:'flex', height: 425, width: '100%', clear:'both' }}>
              <DataGrid rows={usersList} columns={columns} pageSize={5}
                  disableSelectionOnClick
              />
          </div>
          }
      </>
  );
};

export default UsersList;

