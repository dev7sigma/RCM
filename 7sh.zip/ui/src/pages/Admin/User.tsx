import React, { useState,  useMemo  } from "react";
import {
  withStyles,
  makeStyles,
  useTheme
} from '@material-ui/core/styles';
import { Link } from "react-router-dom";
import SupervisedUserCircle from '@material-ui/icons/SupervisedUserCircle';
import { API } from "../../utils/constants";
import RequestApi from '../../service/RequestApi';

// Input components
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import Button from '@material-ui/core/Button';
import clsx from  'clsx';
import {useFormControls} from './UserCreateFormControls'
import Input from '@material-ui/core/Input';
import Chip from '@material-ui/core/Chip';
import { Helmet } from "react-helmet";
import PageTitle from "../../components/PageTitle";
import NotificationBar from '../../components/NotificationBar';

//password section components
import InputAdornment from '@material-ui/core/InputAdornment';
import IconButton from '@material-ui/core/IconButton';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import { green } from '@material-ui/core/colors';
import { APP_TITLE, PAGE_TITLE_ADMIN_ADD_USER, SCHEMES, LOCAL_HOST } from "../../utils/constants";

const usertypes = [
    {
      key:'FO',
      value:'Front Office'
    },
    {
      key:'BO',
      value:'Back Office'
    },
    {
      key:'TL',
      value:'TL'
    },
    {
      key:'Admin',
      value:'Admin'
    }
];
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};


function getStyles(name:any, scheme:any, theme:any) {
  return {
    fontSize:"10pt",
    fontWeight:
    scheme.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const userTypeList = usertypes.map((type, index) =>
  <MenuItem key={type.value}  value={type.value}>{type.value}</MenuItem>
);

const adminTypes = [
  {
    key:'L1',
    value:'Level 1'
  },
  {
    key:'L2',
    value:'Level 2'
  },
  {
    key:'L3',
    value:'Level 3'
  }
]

const adminTypeList = adminTypes.map((type, index) =>
  <MenuItem key={type.value} value={type.value}>{type.value}</MenuItem>
);

const schemes = SCHEMES;

const UsersTextField = withStyles({
  root: {   
    '& label.MuiInputLabel-root': {
      fontSize:'10pt'
    },
    '& .MuiOutlinedInput-root': {
      '&:hover fieldset': {
        fontSize:'9pt'
      },
    },
  },
})(TextField);

const GeneratePassword = withStyles((theme) => ({
  root: {
    color: "#fff",
    backgroundColor: green[500],
    '&:hover': {
      backgroundColor: green[700],
    },
    padding:"5px 10px",
    textTransform:"none"
  },
}))(Button);

const CustomSelect =  withStyles((theme) => ({
  root: {
    padding:"10px",
  },
}))(Select);


const PasswordField = withStyles({
  root: {
    width:"250px",
    '& .MuiOutlinedInput-input':{
      padding:"8px"
    },
    '& .MuiIconButton-edgeEnd':{
      marginRight:"50px"
    }
  },
})(OutlinedInput);

const EmailTextField = withStyles({
  root: {
    width:"300px",
    margin:"8px 12px",
    '& label.MuiInputLabel-root': {
      fontSize:'10pt'
    },
    '& .MuiOutlinedInput-root': {
      '&:hover fieldset': {
        fontSize:'9pt'
      },
    },
  },
})(TextField);

const SelectLabel =  withStyles({
  root: {
    margin:"-10px 0px"
  },
})(InputLabel);

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  muiSelect: {
    "& .MuiSelect-outlined": {
      fontSize: "10pt"
    }
  },
  select: {
    "& ul": {
      backgroundColor: "#f7f3f3",
    },
    "& li": {
      fontSize: 12,
    }
  },
  selectAdminType: {
    "& ul": {
      backgroundColor: "#f7f3f3",
    },
    "& li": {
      fontSize: 12,
    },
    width:"200px"
  },
  form:{
    display:"block"
  },
  margin: {
    margin: theme.spacing(1),
  },
  copyBtn:{
    margin: "0px 0px 4px -65px",
  },
  formControl: {
    margin: "0 10px",
    minWidth: 120,
  },
  selectFormControl :{
    margin: "10px 10px 0 10px",
    minWidth: 210,
    "& .MuiFormLabel-filled":{
      margin:"0"
    }
  },
  InputLabel:{
    fontSize:'11pt',
    '& .MuiSelect-selectMenu' : {
      fontSize:'12pt',
    }
  },
  divStyling:{
    margin: "20px 0 0 0",
  },
  fontSize:{
    fontSize:'10pt'
  },

  divGeneratePass:{
    margin: "20px 0 0 0",
    padding:"10px",
    width:"500px",
    backgroundColor:"#e2f1f9",
    borderRadius:"10px",
  },
  enterPassword:{
    margin:"0 0 10px 0",
    fontSize:'10pt',
  },

  primaryButton:{
    backgroundColor:"#4caf50"
  },

  ml20:{
    marginLeft:"20px"
  },
  ml10:{
    marginLeft:"10px"
  },
  chips: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  chip: {
    margin: 2,
  }
  
}));

export default function User(props:any) {
  console.log("User props==>", props);
  const classes = useStyles();
  const theme = useTheme();
  const [password, setPassword] = useState({
    password: '',
    showPassword: false,
  });
  
  const [show, setShow] = useState(true);
  const [sankbar, setSnakBar] = useState(false);
  const [snackBarSeverity, setSnackBarSeverity] = useState("success" as any);
  const [snackBarMsg, setSnackBarMsg] = useState('');
  const [scheme, setScheme] = useState([]);
  const [stopRender, setStopRender] = useState(false);

  const resetData = () => {
    setSnakBar(false);
    setPassword({ ...password, password: ""});
    if(snackBarSeverity !== "error"){
      resetValues();
      setScheme([]);
    }
  }

  const handlePasswordChange = (prop:any) => (e:any) => {
    setPassword({ ...password, [prop]: e.target.value });
    handleInputValue(e);
  };

  const handleSchemesChange = (e:any) => {
    setScheme(e.target.value);
    handleMultiSelect(e);
  };

  const handleClickShowPassword = () => {
    setPassword({ ...password, showPassword: !password.showPassword });
  };

  const handleMouseDownPassword = (e:any) => {
    e.preventDefault();
  };

  const {
    handleInputValue,
    handleMultiSelect,
    formIsValid,
    errors,
    values,
    resetValues,
    setEditUserDetails,
    handlePassword
  } = useFormControls();

  const generatePassword = () => {
    let length:number = 7;
    let randomPassword           = '';
    let characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let charactersLength = characters.length;
    for ( let i = 0; i < length; i++ ) {
      randomPassword += characters.charAt(Math.floor(Math.random() *  charactersLength));
    }
    console.log(randomPassword);
    handlePassword(randomPassword);
    setPassword({ ...password, "password": randomPassword});
  }

  useMemo(() => {
    if(props.isEditUser){
      setEditUserDetails(props.userDetails);
      let scheme:any = props.userDetails.schemes ? props.userDetails.schemes.split(",") : [];
      setScheme(scheme);
      setStopRender(true);
      setShow(false);
    }
    else if(!props.isEditUser){
      setShow(true);
    }
  }, [props]);



  const submitUserUrl = LOCAL_HOST + API.submitUser;

  const submitUser = (userData:any) => {
    RequestApi.requestData("POST", submitUserUrl, userData)
      .then(data => {
        if(data.status && data.status !== "200"){
          setSnackBarSeverity("error");
          setSnackBarMsg(`User's Email and Mobile already Exists in the system!`);
        }
        else if(data.id){
          setSnackBarSeverity("success")
          setSnackBarMsg(`User: ${data.name} Successfully added to the record!`);
        }
        setSnakBar(true);
    });
  }

  const updateUserDetails = (userData:any) => {
    let putUserUrl = `${submitUserUrl}/${userData.id}`
    RequestApi.requestData("PUT", putUserUrl, userData)
      .then( (data:any) => {
        if(data.id){
          props.successCallback(data);
        }
    });
  }

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    const isValid = Object.values(errors).every((x) => x === "") && formIsValid();
    if (isValid) {
      if(!props.isEditUser){
        await submitUser(values);
      }
      else{
        await updateUserDetails(values);
      }
    }
  };

  return (
    <>
        <NotificationBar snackBar={sankbar} severity={snackBarSeverity} message={snackBarMsg}  onHide={resetData}></NotificationBar>
        { (!props.isEditUser) ? 
        <><Link to="/admin/users" style={{ fontSize:'10pt', textDecoration: 'none'}}>
        <Chip
          style={{ cursor:'pointer', marginBottom:'10px' }}
          icon={<SupervisedUserCircle />}
          label="Users"
        />
        </Link>
          <Helmet>
              <title>
                  {PAGE_TITLE_ADMIN_ADD_USER} | {APP_TITLE}
              </title>
          </Helmet>
          <div className={classes.root}>
              <PageTitle title={PAGE_TITLE_ADMIN_ADD_USER} />
          </div>
          </>
      :""}
      <form className={classes.form} noValidate>
      <div className={classes.divStyling} key="1">
        <UsersTextField
          className={classes.margin}
          label="User Name"
          variant="outlined"
          id="userName"
          margin = "dense"
          name="name"
          required
          value={values.name}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['userName']}
          helperText ={errors['userName']}
          key="2"
          autoComplete="off"
          />

        <EmailTextField
          label="User Email"
          variant="outlined"
          id="userEmail"
          margin = "dense"
          name="email"
          required
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['userEmail']}
          helperText ={errors['userEmail']}
          key="3"
          value={values.email}
          autoComplete="off"
        />
        
        <UsersTextField
          className={classes.margin}
          label="User Mobile"
          variant="outlined"
          id="userMobile"
          margin = "dense"
          name="mobile"
          required
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['userMobile']}
          helperText ={errors['userMobile']}
          key="4"
          value={values.mobile}
          autoComplete="off"
          />
        </div>

        
      <div className={classes.divStyling}  key="5">
      <FormControl variant="outlined" className={classes.selectFormControl}  key="51">
        <SelectLabel className={classes.InputLabel}>User Type</SelectLabel>
        <CustomSelect MenuProps={{ classes: { paper: classes.select } }}  className={classes.muiSelect}
          onChange={handleInputValue}
            onBlur={handleInputValue}
          label="User Type"
          name="type"
          value={values.type}
          
        >
          {userTypeList}
        </CustomSelect>
      </FormControl>

      <FormControl variant="outlined" className={classes.selectFormControl} key="52">
        <SelectLabel className={classes.InputLabel}>Admin Type</SelectLabel>
        <CustomSelect MenuProps={{ classes: { paper: classes.select } }}  className={classes.muiSelect}
          onChange={handleInputValue}
            onBlur={handleInputValue}
          label="Admin Type"
          name="adminType"
          value={values.adminType}
        >
          {adminTypeList}
        </CustomSelect>
      </FormControl>
      </div>
      <div className={classes.divStyling}  key="6">
      <FormControl className={classes.selectFormControl}>
        <InputLabel id="demo-mutiple-chip-label" className={classes.fontSize}>Scheme</InputLabel>
        <Select
          labelId="demo-mutiple-chip-label"
          id="schemes"
          multiple
          name="schemas"
          value={scheme}
          onChange={handleSchemesChange}
          input={<Input id="select-multiple-chip" />}
          renderValue={(selected:any) => (
            <div className={classes.chips}>
              {selected.map((value:any) => (
                <Chip key={value} label={value} className={classes.chip} />
              ))}
            </div>
          )}
          MenuProps={MenuProps}
        >
          {schemes.map((scheme:any) => (
            <MenuItem  key={scheme.key} value={scheme.value} style={getStyles(scheme, scheme.value, theme)}>
              {scheme.value}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      </div>

      { show ? 
      <div className={classes.divGeneratePass}  key="7">
        <InputLabel htmlFor="outlined-adornment-password" className={classes.enterPassword}>Enter / Generate Password</InputLabel>
        <PasswordField
            type={password.showPassword ? 'text' : 'password'}
            value={password.password}
            onChange={handlePasswordChange('password')}
            name="password"
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                  edge="end"
                >
                  {password.showPassword ? <Visibility /> : <VisibilityOff />}
                </IconButton>
              </InputAdornment>
            }
            labelWidth={70}
          />
          <Button variant="contained" size="small" color="primary" className={classes.copyBtn}
           onClick={() => {navigator.clipboard.writeText(password.password)}}>
          copy
        </Button>

      <GeneratePassword variant="contained" color="primary" className={classes.margin} onClick={()=> generatePassword()}>
       Generate Password
      </GeneratePassword>
      </div>
      :""}


      <div className={classes.divStyling}>
        <Button className={clsx(classes.primaryButton, classes.ml10)} variant="contained" 
         disabled={!formIsValid()}
        onClick = {handleFormSubmit}
        color="primary">
           {show ? 'Submit' : "Save" }
        </Button>
      </div>
        
      </form>
    </>
  );
}


