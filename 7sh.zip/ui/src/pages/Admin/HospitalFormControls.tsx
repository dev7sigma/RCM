import { useState } from "react";

const PostUsersForm = async (
  values: any,
  successCallback: any,
  errorCallback: any
) => {
  if (true) successCallback();
  else errorCallback();
};

const initialFormValues = {
  name: "",
  regNo: "",
  email:"",
  place:"",
  locality:"",
  city:"",
  district:"",
  message: "",
  state:"",
  pinCode:"",
  type:"",
  webSite:"",
  fax:"",
  phone:"",
  schemas:""
};

export const HospitalFormControls = () => {
  const [values, setValues] = useState(initialFormValues);
  const [errors, setErrors] = useState({} as any);

  const validate: any = (fieldValues = values) => {
    let temp: any = { ...errors };

    if ("name" in fieldValues){
      temp.name = fieldValues.name ? "" : "Name is required.";
    }
    if ("regNo" in fieldValues){
      temp.regNo = fieldValues.regNo ? "" : "Registration # is required.";
    }
    if ("district" in fieldValues) {
        temp.district = fieldValues.district ? "" : "District is required.";
    }
    if ("city" in fieldValues){
        temp.city = fieldValues.city ? "" : "City is required.";
    }
    if ("state" in fieldValues) {
        temp.state = fieldValues.state ? "" : "State is required.";
    }
    if ("pinCode" in fieldValues){
        temp.pinCode = fieldValues.pinCode ? "" : "Pin Code is required.";
    }
    if ("schemas" in fieldValues){
      temp.schemas = fieldValues.schemas ? "" : "scheme is required.";
    }

    if ("phone" in fieldValues){
      temp.phone = fieldValues.phone ? "" : "Pin Code is required.";
  }

    if ("email" in fieldValues) {
      temp.email = fieldValues.email ? "" : "Email is required.";
      if (fieldValues.email)
        temp.userEmail = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(fieldValues.email)
          ? ""
          : "Email is not valid.";
    }

    setErrors({
      ...temp
    });
  };

  const handleInputValue = (e: any) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value
    });
    validate({ [name]: value });
  };

  const handleMultiSelect = (e: any) => {
    const {name, value } = e.target;

    if(value){
      setValues({
        ...values,
        [name]: value.join(',')
      });
      validate({ [name]: value });
    }
  };

  const handleError = () => {
    resetValues()
  };

  const resetValues = () => {
    setValues({
      ...initialFormValues,
    });
  }

  const formIsValid = (fieldValues = values) => {
    const isValid =
      fieldValues.name 
      && fieldValues.email 
      && fieldValues.pinCode 
      && fieldValues.state
      && fieldValues.regNo
      && fieldValues.district
      && fieldValues.phone
      Object.values(errors).every((x) => x === "");

    return isValid;
  };

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    const isValid =
      Object.values(errors).every((x) => x === "") && formIsValid();
    if (isValid) {
      await PostUsersForm(values, resetValues, handleError);
    }
  };

  const setHospitalDetails = (hospitalDetails:any) =>{
    setValues({
      ...hospitalDetails
    });
  }

  return {
    values,
    errors,
    handleInputValue,
    handleMultiSelect,
    handleFormSubmit,
    formIsValid,
    resetValues,
    setHospitalDetails
  };
};

