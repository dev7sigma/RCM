import React, { FC, ReactElement, useState } from 'react';
import { Helmet } from 'react-helmet';
import { makeStyles, createStyles, Theme, withStyles } from "@material-ui/core/styles";
import {
    DataGrid,
} from "@material-ui/data-grid";
import Button from '@material-ui/core/Button';
import DeleteIcon from '@material-ui/icons/Delete';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContentText from '@material-ui/core/DialogContentText';
import CircularProgress from '@material-ui/core/CircularProgress';
import EditIcon from '@material-ui/icons/Edit';
// components
import PageTitle from "../../components/PageTitle";
import RequestApi from '../../service/RequestApi';
import * as _ from "lodash";
import BulkUpload from './BulkUpload';
import NotificationBar from '../../components/NotificationBar';

// constants
import { APP_TITLE, PAGE_TITLE_ADMIN_DOCTORS, LOCAL_HOST, API, defaultDoctorData } from '../../utils/constants';
import Doctor from './Doctor';
const DOCTORS_URL = LOCAL_HOST + API.DOCTORS;

const departmentIcon = <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAgUlEQVRIie2T0Q2AIAxEW+MYDsM0rskwuMf5Qw02QtACidH32cK1VwrR22EdAACTIPNJc7KIfRAAHnZ8Ttw1EBdcr+6FwwUnBUzrqZF1Hbum4q/l/e4O5lJSdyNzzcWv6O7g/QWKb1CabS3DHWxEtNz9C+p8SHPawRqLPCVEjZ96dnfGESrX9xtDAAAAAElFTkSuQmCC"/>;

// define css-in-js
const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            flex: 1,
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
        },
        dialogContent:{
            width:"600px"
        },
        textField:{
            width:300
        }
    })
);


const CustomDialog = withStyles({
  root: {
    '& .MuiDialog-paperWidthSm': {
     maxWidth:'875px'
    },
    '& .MuiDialogContent-root': {
      width:'100%'
     },

  },
})(Dialog);

const rows = [
  {
      id:1,
      name:"Narayan",
      regNo:'123456',
      department:'Oncology',
      email:'Narayan@g.com',
      qualification:'MBBS',
      phone:'123467890'
  },
  {
      id:2,
      name:"Rajesh",
      regNo:'123456',
      department:'Neurology',
      email:'Rajesh@g.com',
      qualification:'MBBS, MD',
      phone:'123467890'
  },
];

const DoctorsList: FC<{}> = (): ReactElement => {
    const classes = useStyles();
    const [sankbar, setSnakBar] = React.useState(false);
    const [snackBarMsg, setSnackBarMsg] = React.useState('');
    const [deleteDoctor, setDeleteDoctor]  = React.useState(false);
    const [isEditDoctor, setEditDoctor]  = React.useState(false);
    const [addDoctor, setAddDoctor]  = React.useState(false);
    const [selectedDoctor, setDoctorValue] = React.useState(defaultDoctorData);
    const [doctorsList, setDoctorsList] = React.useState([] as any);
    const [getDoctorsFlag, setDoctorsFlag]  = React.useState(true);
    const [showSpinner, setShowSpinner] = React.useState(true);
    const [snackBarSeverity, setSnackBarSeverity] = useState("success" as any);

    const getDoctors = () => {
      RequestApi.requestData("GET", DOCTORS_URL, {}) 
      .then( (data:any) => {
        setDoctorsList(data);
        setShowSpinner(false);
      });
    }

    if(!doctorsList.length && getDoctorsFlag){
      setDoctorsFlag(false);
      getDoctors();
    } 

    const removeDoctor = (doctor:any) => {
        setDoctorValue(doctor);
        resetFlags();
        setDeleteDoctor(true);
        console.log("remove doctor::", doctor);
    }

    const editDcotor = (doctor:any) => {
      setDoctorValue(doctor);
      resetFlags();
      setEditDoctor(true);
      setAddDoctor(true);
      console.log("edit doctor::", doctor);
    }
 

    const deleteDoctorAction = () => {
      let deleteUserUrl = `${DOCTORS_URL}/${selectedDoctor.id}`;
      RequestApi.requestData("DELETE", deleteUserUrl, {})
        .then( (response:any) => {
          resetFlags();
          setDeleteDoctor(false);
          setSnakBar(true);
          setSnackBarMsg(`Doctor: ${selectedDoctor.name} Successfully deleted!`);
          let newDoctorList = doctorsList.filter((doctor:any) => {
            return doctor['id'] != selectedDoctor.id
          });
          setDoctorsList(newDoctorList);
      }).catch(function(e){
        console.log("e==>", e);
      });
    }
       
    //Sample Data
    const columns = [
    {
        field: 'name',
        headerName: 'Doctor Name',
        width: 200,
        editable: false,
    },
    {
        field: 'regNo',
        headerName: 'Registration #',
        width: 150,
        editable: false,
    },
    {
        field: 'email',
        headerName: 'Email',
        width: 200,
        editable: false,
    },
    {
        field: 'department',
        headerName: 'Department',
        width: 200,
        editable: false,
    },
    {
        field: 'qualification',
        headerName: 'Qualification',
        width: 150,
        editable: false,
    },
    {
        field: "",
        headerName:"Action",
        sortable: false,
        filterable: false,
        disableClickEventBubbling: true,
        renderCell: (params:any) => {
          const rowData = params.row;
          return (<>
          <EditIcon style={{fill: "#3e2fa2", cursor:'pointer', margin:'10px'}} onClick = {() => editDcotor(rowData)}></EditIcon>
          <DeleteIcon style={{fill: "#ce2727", cursor:'pointer'}} onClick = {() => removeDoctor(rowData)}/>
          </>
          );
        }
      }
  ];
  
  const handleClose = () => {
    resetFlags();
    setDoctorValue(defaultDoctorData);
  };
  
  const deleteDepartmentDialog = (
    <>
    <Dialog 
          open={deleteDoctor}
          keepMounted
          onClose={handleClose}
          aria-labelledby="alert-dialog-slide-title"
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle id="alert-dialog-slide-title">Delete Doctor</DialogTitle>
          <DialogContent dividers  className={classes.dialogContent}>
            <DialogContentText id="alert-dialog-slide-description">
               Are you sure to Delete Doctor
               <br/> <b> {selectedDoctor.name}?</b>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              CANCEL
            </Button>
            <Button onClick={deleteDoctorAction} color="primary">
              YES
            </Button>
          </DialogActions>
        </Dialog>
        </>
  );

  const saveDoctor = (e:any) => {
    setDoctorValue(e.target.value);
  }

  const onDoctorSubmit = (response:any) => {
    
    const newList = [...doctorsList];
    if(response.status && response.status !== "200"){
      setSnackBarSeverity("error");
      setSnackBarMsg(`Doctor's Registration Number already Exists in the system!`);
    }
    else if(response.id){
      resetFlags();
     
      setSnackBarMsg(`Doctor: ${response.name} Successfully Updated!`);
      if(isEditDoctor){
          let foundIndex = _.findIndex(doctorsList, {id:response.id});
          if(foundIndex !== -1){
            newList[foundIndex] = response;
          }
      }
      else{
        newList.push(response);
      }
      setDoctorsList(newList);
    }
    setSnakBar(true);
 }

  const addEditDepartmentDialog = (
    <>
    <CustomDialog 
          open={addDoctor}
          keepMounted
          onClose={handleClose}
          aria-labelledby="alert-dialog-slide-title"
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle id="alert-dialog-slide-title">{ isEditDoctor ? 'Edit Doctor' : 'Add Doctor'}</DialogTitle>
          <DialogContent dividers  className={classes.dialogContent}>
            <DialogContentText id="alert-dialog-slide-description">
              <Doctor onSubmit={onDoctorSubmit} isEditDoctor={isEditDoctor} doctorDetails={selectedDoctor}></Doctor>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              CLOSE
            </Button>
            
          </DialogActions>
        </CustomDialog>
        </>
  );

  const openAddDoctor = () => {
    setDoctorValue(defaultDoctorData);
    resetFlags();
    setAddDoctor(true);
  }

  const resetFlags = () => {
    setDeleteDoctor(false);
    setSnakBar(false);
    setAddDoctor(false);
    setEditDoctor(false);
    setSnackBarSeverity("success");
  }

    return (
        <>
            {deleteDepartmentDialog}
            {addEditDepartmentDialog}
            <NotificationBar snackBar={sankbar} severity={snackBarSeverity} message={snackBarMsg}></NotificationBar>
            <Helmet>
                <title>{PAGE_TITLE_ADMIN_DOCTORS} | {APP_TITLE}</title>
            </Helmet>
            <div className={classes.root}>
                <PageTitle title={PAGE_TITLE_ADMIN_DOCTORS} />
            </div>
            <div>
                <div style={{display:"block", float:'right'}}>
                    <BulkUpload moduleName="Doctors"></BulkUpload>
                    <Button variant="contained" color="primary" size="small"  startIcon={departmentIcon}  onClick={() => openAddDoctor()} >
                        Add Doctor
                    </Button>
                </div>
                <div style={{clear:'both'}}></div>
                {showSpinner ?  <CircularProgress disableShrink /> : 
                <div style={{ display:'flex', height: 600, width: '100%', clear:'both', margin:"20px 20px 20px 0" }}>
                <DataGrid
                    rows={doctorsList}
                    columns={columns}
                    disableSelectionOnClick
                />
                </div>
                }     
          </div>
        </>
    )
}

export default DoctorsList;