import React, { FC, ReactElement } from "react";
import { withStyles } from "@material-ui/core/styles";
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';

const CustomDialogElement = withStyles({
    root: {
      '& .MuiDialog-paperWidthSm': {
       maxWidth:'875px'
      }
    },
})(Dialog);

export default function CustomDialog(props:any) {
    const [bulkUpload, setBulkUpload] = React.useState(false);
    const handleClose = () => {
        
    };
    return (
        <>
        <CustomDialogElement 
              open={props.open}
              keepMounted
              onClose={handleClose}
              aria-labelledby="alert-dialog-slide-title"
              aria-describedby="alert-dialog-slide-description"
            >
              <DialogTitle id="alert-dialog-slide-title">Edit User</DialogTitle>
              <DialogContent dividers>
                {props.component}
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClose} color="primary">
                  CLOSE
                </Button>
              </DialogActions>
            </CustomDialogElement>
            </>
    )
}