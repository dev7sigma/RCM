import React, { FC, ReactElement } from 'react';
import { Helmet } from 'react-helmet';
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";
import {
    DataGrid,
} from "@material-ui/data-grid";
import Button from '@material-ui/core/Button';
import DeleteIcon from '@material-ui/icons/Delete';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContentText from '@material-ui/core/DialogContentText';
import CircularProgress from '@material-ui/core/CircularProgress';
import TextField from '@material-ui/core/TextField';
// components
import PageTitle from "../../components/PageTitle";
import RequestApi from '../../service/RequestApi';
import BulkUpload from './BulkUpload';
import NotificationBar from '../../components/NotificationBar';

// constants
import { APP_TITLE, PAGE_TITLE_ADMIN_DEPARTMENTS, API, LOCAL_HOST } from '../../utils/constants';
const getAllDepartments = LOCAL_HOST + API.DEPARMENTS;

const departmentIcon = <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAgUlEQVRIie2T0Q2AIAxEW+MYDsM0rskwuMf5Qw02QtACidH32cK1VwrR22EdAACTIPNJc7KIfRAAHnZ8Ttw1EBdcr+6FwwUnBUzrqZF1Hbum4q/l/e4O5lJSdyNzzcWv6O7g/QWKb1CabS3DHWxEtNz9C+p8SHPawRqLPCVEjZ96dnfGESrX9xtDAAAAAElFTkSuQmCC"/>;

// define css-in-js
const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            flex: 1,
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
        },
        dialogContent:{
            width:"600px"
        },
        textField:{
            width:300
        }
    })
);


const DepartmentsList: FC<{}> = (): ReactElement => {
    const classes = useStyles();
    const [sankbar, setSnakBar] = React.useState(false);
    const [snackBarMsg, setSnackBarMsg] = React.useState('');
    const [deleteDepartment, setDeleteDepartment]  = React.useState(false);
    const [addDepartment, setAddDepartment]  = React.useState(false);
    const [selectedDepartment, setDepartmentValue] = React.useState({name:"", id:0});
    const [newDepartment, setDepartmentName]  = React.useState('');
    const [showSpinner, setShowSpinner] = React.useState(true);
    const [departmentList, setDepartmentList] = React.useState ([] as any);
    const [getDepartmentFlag, setDepartmentFlag]  = React.useState(true);

    const getDepartments = () => {
      RequestApi.requestData("GET", getAllDepartments, {})
      .then( list => {
        setShowSpinner(false);
        setDepartmentList(list);
      });
    }
    
    if(!departmentList.length && getDepartmentFlag){
      setDepartmentFlag(false);
      getDepartments();
    }

    const removeDepartment = (department:any) => {
        setDepartmentValue(department);
        resetFlags();
        setDeleteDepartment(true);
        console.log("remove dept::", department);
        
    }
    const deleteDepartmentAction = () => {
      let deleteUserUrl = getAllDepartments +'/'+ selectedDepartment.id;
      RequestApi.requestData("DELETE", deleteUserUrl, {})
        .then( (response) => {
         deleteSuccess();
      }).catch(function(e){
        console.log("error==>", e);
      });
    }
       
    //Sample Data
    const columns = [
    {
        field: 'name',
        headerName: 'Department Name',
        width: 500,
        editable: false,
    },
    
    {
        field: "",
        headerName:"Action",
        sortable: false,
        filterable: false,
        disableClickEventBubbling: true,
        renderCell: (params:any) => {
          const rowData = params.row;
          return (<DeleteIcon style={{fill: "#423b3b", cursor:'pointer'}} onClick = {() => removeDepartment(rowData)}/>);
        }
      }
  ];
  
  const handleClose = () => {
    resetFlags();
  };
  
  const deleteDepartmentDialog = (
    <>
    <Dialog 
          open={deleteDepartment}
          keepMounted
          onClose={handleClose}
          aria-labelledby="alert-dialog-slide-title"
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle id="alert-dialog-slide-title">Delete Hospital</DialogTitle>
          <DialogContent dividers  className={classes.dialogContent}>
            <DialogContentText id="alert-dialog-slide-description">
               Are you sure to Delete Department
               <br/> <b> {selectedDepartment.name}?</b>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              CANCEL
            </Button>
            <Button onClick={deleteDepartmentAction} color="primary">
              YES
            </Button>
          </DialogActions>
        </Dialog>
        </>
  );

  const saveDepartment = (e:any) => {
      setDepartmentName(e.target.value);
  }

  const addDepartmentDialog = (
    <>
    <Dialog 
          open={addDepartment}
          keepMounted
          onClose={handleClose}
          aria-labelledby="alert-dialog-slide-title"
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle id="alert-dialog-slide-title">Add Department</DialogTitle>
          <DialogContent dividers  className={classes.dialogContent}>
            <DialogContentText id="alert-dialog-slide-description">
              <TextField 
               label="Department Name"
               id="departmentName"
               margin = "dense"
               name="name"
               value={newDepartment}
            className={classes.textField}
            onChange={saveDepartment}
              ></TextField>
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              CLOSE
            </Button>
            <Button onClick={() => {addDepartmentAction()}} color="primary">
              ADD
            </Button>
          </DialogActions>
        </Dialog>
        </>
  );

  const openAddDepartment = () => {
    resetFlags();
    setAddDepartment(true);
  }

  const resetFlags = () => {
    setDeleteDepartment(false);
    setSnakBar(false);
    setAddDepartment(false);
    setDepartmentName('');
  }

  const deleteSuccess = () => {
    resetFlags();
    setDeleteDepartment(false);
    setSnakBar(true);
    setSnackBarMsg(`Department: ${selectedDepartment.name} Successfully deleted!`);
    let newHospitalsList = departmentList.filter((dep:any) => {
      return dep['id'] !== selectedDepartment.id
    });
    setDepartmentList(newHospitalsList);
  }


  const addDepartmentAction = () => {
    RequestApi.requestData("POST", getAllDepartments, {name:newDepartment})
    .then( (data:any) => {
      if(data.id){
        setSnakBar(true);
        const newList = [...departmentList];
        newList.push(data);
        setDepartmentList(newList);
        setSnackBarMsg(`Department: ${newDepartment} Successfully Added!`);
        resetFlags();
        setAddDepartment(true);
      }
    }).catch(function(e){
      console.log("e==>", e);
     });
  }

    return (
        <>
            {deleteDepartmentDialog}
            {addDepartmentDialog}
            <NotificationBar snackBar={sankbar} severity="success" message={snackBarMsg}></NotificationBar>
            <Helmet>
                <title>{PAGE_TITLE_ADMIN_DEPARTMENTS} | {APP_TITLE}</title>
            </Helmet>
            <div className={classes.root}>
                <PageTitle title={PAGE_TITLE_ADMIN_DEPARTMENTS} />
            </div>
            <div>
                <div style={{marginTop:"50px", width:"60%", textAlign:"right"}}>
                <BulkUpload moduleName="Departments"></BulkUpload>
                    <Button variant="contained" color="primary" size="small"  startIcon={departmentIcon}  onClick={() => openAddDepartment()} >
                        Add Department
                    </Button>
                </div>

                {showSpinner ?  <CircularProgress disableShrink /> : 
                <div style={{ display:'flex', height: 600, width: '60%', clear:'both', margin:"20px 20px 20px 0" }}>
                  <DataGrid
                      rows={departmentList}
                      columns={columns}
                      disableSelectionOnClick
                  />
                </div>
              }
          </div>
        </>
    )
}

export default DepartmentsList;