import { useState } from "react";

const initialFormValues = {
  name: "",
  email: "",
  mobile:"",
  type:"",
  adminType:"",
  schemas:"",
  password:""
};

export const useFormControls = () => {
  const [values, setValues] = useState(initialFormValues);
  const [errors, setErrors] = useState({} as any);
  const PASSWORD_MIN_CHARS = 2;
  const validate: any = (fieldValues = values) => {
    let temp: any = { ...errors };
    
    if ("name" in fieldValues){
      temp.name = fieldValues.name ? "" : "Name is required.";
    }
    if ("mobile" in fieldValues) {
        temp.userMobile = fieldValues.mobile ? "" : "Mobile is required.";
    }
    if ("type" in fieldValues){
        temp.type = fieldValues.type ? "" : "Type is required.";
    }
    if ("adminType" in fieldValues) {
        temp.adminType = fieldValues.adminType ? "" : "Admin Type is required.";
    }
    if ("schemas" in fieldValues){
        temp.schemas = fieldValues.schemas ? "" : "scheme is required.";
    }

    if ("password" in fieldValues){
      temp.password = fieldValues.password ? "" : "Password is required.";
    }

    if ("email" in fieldValues) {
      temp.userEmail = fieldValues.email ? "" : "Email is required.";
      if (fieldValues.email)
        temp.userEmail = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(fieldValues.email)
          ? ""
          : "Email is not valid.";
    }

    setErrors({
      ...temp
    });
  };

  const handleInputValue = (e: any) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value
    });
    validate({ [name]: value });
  };

  const resetValues = () => {
    setValues({
      ...initialFormValues,
    });
  }

  const handleMultiSelect = (e: any) => {
    const {name, value } = e.target;

    /* const multiSelect = [];
    for (let i = 0, l = value.length; i < l; i += 1) {
      if (value[i].selected) {
        multiSelect.push(value[i].value);
      }
    } */
    if(value){
      setValues({
        ...values,
        [name]: value.join(',')
      });
      validate({ [name]: value });
    }
  };

  const handleSuccess = () => {
    setValues({
      ...initialFormValues
    });
  };

  const handleError = () => {
    setValues({
      ...initialFormValues
    });
  };

  const setEditUserDetails = (userDetails:any) =>{
    setValues({
      ...userDetails
    });
  }

  const formIsValid = (fieldValues = values) => {
    const isValid =
      fieldValues.name && fieldValues.email && fieldValues.mobile && fieldValues.adminType && fieldValues.type
      && fieldValues.schemas  && fieldValues.password.length > PASSWORD_MIN_CHARS
      Object.values(errors).every((x) => x === "");

    return isValid;
  };

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    console.log("values==>", values);
    const isValid = Object.values(errors).every((x) => x === "") && formIsValid();
    if (isValid) {
      console.log("isValid==>", isValid);
    }
  };

  const handlePassword = (password:string) => {
    setValues({
      ...values,
      ['password']: password
    });
    validate({ ['password']: password });
  }

  return {
    values,
    errors,
    handleInputValue,
    handleMultiSelect,
    handleFormSubmit,
    formIsValid,
    resetValues,
    setEditUserDetails,
    handlePassword
  };
};
