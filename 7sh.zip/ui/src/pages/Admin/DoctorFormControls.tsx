import { useState } from "react";

const PostUsersForm = async (
  values: any,
  successCallback: any,
  errorCallback: any
) => {
  if (true) successCallback();
  else errorCallback();
};

const initialFormValues = {
  name: "",
  regNo: "",
  email:"",
  contactNumber:"",
  department:"",
  qualification:""
};

export const DoctorFormControls = () => {
  const [values, setValues] = useState(initialFormValues);
  const [errors, setErrors] = useState({} as any);

  const validate: any = (fieldValues = values) => {
    let temp: any = { ...errors };

    if ("name" in fieldValues){
      temp.name = fieldValues.name ? "" : "Name is required.";
    }

    if ("regNo" in fieldValues){
      temp.regNo = fieldValues.regNo ? "" : "Registration # is required.";
    }
    
    if ("department" in fieldValues){
        temp.city = fieldValues.department ? "" : "Department is required.";
    }

    if ("qualification" in fieldValues) {
        temp.qualification = fieldValues.qualification ? "" : "Qualification is required.";
    }

    if ("contactNumber" in fieldValues){
      temp.contactNumber = fieldValues.contactNumber ? "" : "Phone is required.";
    }

    if ("email" in fieldValues) {
      temp.email = fieldValues.email ? "" : "Email is required.";
      if (fieldValues.email)
        temp.userEmail = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(fieldValues.email)
          ? ""
          : "Email is not valid.";
    }

    setErrors({
      ...temp
    });
  };

  const handleInputValue = (e: any) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value
    });
    validate({ [name]: value });
  };

  const handleError = () => {
    resetValues()
  };

  const resetValues = () => {
    setValues({
      ...initialFormValues,
    });
  }

  const setDepartmentValue = (dept:string) => {
    setValues({
      ...values,
      ['department']: dept
    });
  }

  const formIsValid = (fieldValues = values) => {
    const isValid =
      fieldValues.name 
      && fieldValues.email 
      && fieldValues.department 
      && fieldValues.qualification
      && fieldValues.regNo
      && fieldValues.contactNumber
      Object.values(errors).every((x) => x === "");

    return isValid;
  };

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    const isValid =
      Object.values(errors).every((x) => x === "") && formIsValid();
    if (isValid) {
      await PostUsersForm(values, resetValues, handleError);
    }
  };

  const setDoctorDetails = (doctorDetails:any) =>{
    setValues({
      ...doctorDetails
    });
  }

  return {
    values,
    errors,
    handleInputValue,
    handleFormSubmit,
    formIsValid,
    resetValues,
    setDoctorDetails,
    setDepartmentValue
  };
};

