import React, { FC, ReactElement, useState, ChangeEvent, useEffect } from "react";
import { Helmet } from "react-helmet";
import { makeStyles, createStyles, Theme, withStyles} from "@material-ui/core/styles";
import * as _ from "lodash"; 

// components
import PageTitle from "../../components/PageTitle";
import {
    DataGrid,
} from "@material-ui/data-grid";


import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContentText from '@material-ui/core/DialogContentText';
import Button from '@material-ui/core/Button';
import Link from '@material-ui/core/Link';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CircularProgress from '@material-ui/core/CircularProgress';
import TextField from '@material-ui/core/TextField';
import DeleteIcon from '@material-ui/icons/Delete';
import Grid from '@material-ui/core/Grid';
import ToggleButton from '@material-ui/lab/ToggleButton';
import ToggleButtonGroup from '@material-ui/lab/ToggleButtonGroup';
import HospitalActionMenu from './HospitalActionMenu';
import RequestApi from '../../service/RequestApi';
import BulkUpload from './BulkUpload';

import { APP_TITLE, PAGE_TITLE_ADMIN_HOSPITALS, API, LOCAL_HOST, defaultDoctorData } from "../../utils/constants";
import Hospitals from "./Hospitals";
import NotificationBar from "../../components/NotificationBar";
const getAllHospitals = LOCAL_HOST + API.HOSPITALS_URL;
const getAllDepartments = LOCAL_HOST + API.DEPARMENTS;
const getAllDoctors = LOCAL_HOST + API.DOCTORS;


const AutocompleteField = withStyles({
  root: {
    width:"250px",
    margin:"8px 9px",
    '& label.MuiInputLabel-root': {
      margin:'-10px 10px'
    },
    '& label.Mui-focused': {
      TransformStream:'translate(14px ,6px) scale(0.75)'
    },
    '& .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"]': {
      padding:0,
    },
    '& label.MuiInputLabel-root.MuiInputLabel-outlined.MuiInputLabel-shrink.Mui-focused':{
      TransformStream:'translate(10px ,5px) scale(0.75)'
    }
  },
})(Autocomplete);

const CustomEditHospitalDialog = withStyles({
  root: {
    '& .MuiDialog-paperWidthSm': {
     maxWidth:'875px'
    }
  },
})(Dialog);

const CustomToggleButton = withStyles({
  root:{
    '&.MuiToggleButton-root.Mui-selected':{
      backgroundColor:'#244a75 !important',
      color:'#fff',
      fontWeight:'bold'
    }
  }
})(ToggleButton);

export function AutoCompleteField(props:any) {
      const [autoCompleteOpen, setAutoCompleteOpen] = useState(false);
      const [results, setResults] = useState(Array());
      const loading = !autoCompleteOpen && results.length === 0;
      const [searchVal, setSearchValue] = useState('');
      const [selectedDepartment, setDepartmentValue] = useState('');

      const onSearchTextChange = (event: ChangeEvent<HTMLInputElement>) =>{
        setSearchValue(event.target.value);
      }
      
      const setDepartment = (dept:any) => {
        setDepartmentValue(dept);
        props.provideDepartment(dept);
      };

      React.useEffect(() => {
        
        let active = true;
    
        if (!loading) {
          return undefined;
        }
    
        let url = props.type === 'Department' ? getAllDepartments : getAllDoctors;
        if(!results.length){
          RequestApi.requestData("GET", url, {})
            .then(data => {
              if (active) {
                setResults(data);
                if(props.setDepartments){
                  props.setDepartments(data);
                }
              }
          });
        }

        return () => {
          active = false;
        };
      }, [loading]);
 
  return (
    <AutocompleteField
      style={{ width: 300, display:'inline-block' }}
      open={autoCompleteOpen}
      onOpen={() => {
        setAutoCompleteOpen(true);
      }}
      onClose={() => {
        setAutoCompleteOpen(false);
      }}
      getOptionSelected={(option:any, value:any) => option.name === value.name}
      getOptionLabel={(option:any) => option.name}
      options={results}
      loading={loading}
      onChange={(event, newValue) => {
        setDepartment(newValue);
      }}
      renderInput={(params) => (
        <TextField
          {...params}
          label={props.type}
          variant="outlined"
          onChange = {onSearchTextChange}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <React.Fragment>
                {loading ? <CircularProgress color="inherit" size={20} /> : null}
                {params.InputProps.endAdornment}
              </React.Fragment>
            ),
          }}
        />
      )}
    />
  );
}

// define css-in-js
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flex: 1,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
    },
    toggleContainer: {
      margin: theme.spacing(2, 0),
    },
    adduser:{
        width:150,
        float:"right",
        marginBottom:"20px"
    },
    adduserLink:{
        color:"#fff",
    },
    dialogContent:{
      width:"600px"
    },
    closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500],
    },
    '& .MuiButton-containedSecondary': {
      color: "#fff",
      backgroundColor: "#f50057"
    }
  })
);

const AddHospitalIcon = <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAlUlEQVRIid2VSw6AIAxEwRgOpV7P3z3FazwXYmJIFQLG36yAwkymJa1SvwFggBGYSYcFesBIAkMGsY9OErAuWGVkod6cSEEAUsmPeIpcwhCCAkfOYh0/7+D1AmXsxdQf9h4HWmu938c6+n6Rn6+Bn/vQuY9bUzQrtbbcVDKgcUuxXfcXDpxWEjBOxAYen2ECWqSR+Vks4Px9L+YpBi0AAAAASUVORK5CYII="/>;

const hospitalDetails = {
  id:"",
  name: "",
  regNo: "",
  email:"",
  place:"",
  locality:"",
  city:"",
  district:"",
  message: "",
  state:"",
  pinCode:"",
  type:"",
  webSite:"",
  fax:"",
  phone:"",
  schemes:'',
  departments:[],
  schemeMapping:[]
};

const HospitalsList: FC<{}> = (): ReactElement => {
  const classes = useStyles();
  const [selectedHospital, setSelectedHospital] = useState({} as any);
  const [editHospital, setEditHospital]  = useState(false);
  const [deleteHospital, setDeleteHospital]  = useState(false);
  const [addDoctor, setAddDoctor]  = useState(false);
  const [addDepartment, setAddDepartment]  = useState(false);
  const [sankbar, setSnackBar] = useState(false);
  const [snackBarMsg, setSnackBarMsg] = useState('');
  const [getHospitalFlag, setHospitalFlag]  = useState(true);
  const [hospitalsList, setHospitalList] = useState([]);
  const [showSpinner, setShowSpinner] = useState(true);
  const [mappedDepartments, setMappedDepartments] = useState([] as any);
  const [departmentsForScheme, setSchemeDepartments] = useState([] as any);
  const [mappedDoctors, setMappedDoctors] = useState([] as any);
  const [unMappedDoctors, setUnMappedDoctors] = useState([] as any);
  const [deptsForDelete, setDeptForDelete] = useState([]);
  const [enableDeleteDep, setEnableDeleteDept] = useState(true);
  const [deptForMap, setDeptForMap] = useState({id:0, name:''});
  const [doctorForMap, setDoctorMap] = useState(defaultDoctorData);
  const [mapScheme, setMapScheme] = useState(false);
  const [selectedScheme, setScheme] = useState('');
  const [departmentList, setDepartmentList] = useState([] as any);
  const [hospitalSchemes, setHospitalSchemes] = useState([] as any);
  const [hospitalSchemeMapping, setHospitalSchemeMapping] = useState({
    hospitalId:"",
    schemeMapping:[]
  } as any);


  useEffect(() => {
    console.log("selectedHospital==>", selectedHospital);
  }, [selectedHospital, selectedScheme, departmentList, departmentsForScheme, mappedDoctors, unMappedDoctors]);

  const handleScheme = (event:any, newScheme:any) => {
    if (newScheme !== null) {
      setScheme(newScheme);
      if(_.isEmpty(selectedHospital.schemeMapping)){
        setSchemeDepartments([]);
      }
      else{
        let foundScheme:any = _.find(selectedHospital.schemeMapping, {scheme:newScheme});
        if(foundScheme){
          setSchemeDepartments(foundScheme.departments);
        }
      }
    }
  };

  const commaSpacer = ', ';

  const resetFlags = () => {
    setAddDoctor(false);
    setAddDepartment(false);
    setEditHospital(false);
    setDeleteHospital(false);
    setEnableDeleteDept(true);
    setSnackBar(false);
    setHospitalFlag(true);
    setMapScheme(false);
    setScheme("");
    setSchemeDepartments([]);
  }
  
  const prepareSchemeMappingList = (hospitalDetails:any) => {
    if(_.isEmpty(hospitalDetails.schemeMapping)){
      let schemeMapping:any = [];
      let schemes = hospitalDetails.schemas ? hospitalDetails.schemas.split(",") : [];
      setHospitalSchemes(schemes);
      console.log("schemas==>", hospitalSchemes);
      if(schemes.length){
        schemes.forEach( (scheme:string) => {
          schemeMapping.push( {
            scheme:scheme,
            departments:[]
          });
        });
      }
      hospitalDetails.schemeMapping = schemeMapping;
      setSelectedHospital(hospitalDetails);
      console.log("selectedHospital==>", selectedHospital);
    }
    else{
      let schemes = hospitalDetails.schemeMapping.map( (scheme:any) => {return scheme.scheme});
      setSchemeDepartments( hospitalDetails.schemeMapping.departments);
      setHospitalSchemes(schemes);
    }
  }

  const handleCallback = (action:string, hospitalData:any) => {
    console.log('action==>', action);
    console.log("hospitalData==>", hospitalData);
    setSelectedHospital(hospitalData);
    prepareSchemeMappingList(hospitalData);
    setMappedDepartments(hospitalData.departments && hospitalData.departments.length ?  hospitalData.departments : []);
    setMappedDoctors(hospitalData.doctors && hospitalData.doctors.length ?  hospitalData.doctors : []);
    resetFlags();
      switch(action){
          case 'ADD_DOCTOR':
            setAddDoctor(true);
          break;
          case 'ADD_DEPARTMENT':
            setAddDepartment(true);
          break;
          case 'EDIT_HOSPITAL':
            setEditHospital(true);
          break;
          case 'DELETE_HOSPITAL':
            setDeleteHospital(true);
          break;
          case 'ADD_SCHEME_DEPARTMENT':
            setMapScheme(true);
          break;
      }
}

const mappedDepartmentsCols = [
  {
    field: 'name',
    headerName: 'Department',
    width: 300,
    sortable: false,
    editable: false
  }
];

const mappedDoctorCols = [
  {
    field: 'name',
    headerName: 'Doctor Name',
    width: 200,
    sortable: false,
    editable: false
  },
  {
    field: 'department',
    headerName: 'Department',
    width: 200,
    sortable: false,
    editable: false
  }
];

const columns = [
  {
      field: 'name',
      headerName: 'Name',
      width: 140,
      editable: false,
  },
  {
      field: 'email',
      headerName: 'Email',
      width: 200,
      editable: false,
  },
  {
      field: 'regNo',
      headerName: 'Registration #',
      width: 170,
      editable: false,
  },
  {
      field: 'hAdress',
      headerName: 'Address',
      width: 290,
      editable: false,
      renderCell: (params:any) => {
        const rowData = params.row;
        let addrerss = rowData.city ? rowData.city : "";
        addrerss += `${ rowData.place ? commaSpacer + rowData.place : ''}`
        addrerss += `${ rowData.locality ? commaSpacer + rowData.locality : ''}`
        addrerss += `${ rowData.district ? commaSpacer + rowData.district : ''}`
        addrerss += `${ rowData.state ? commaSpacer + rowData.state : ''}`
        return `${addrerss}`;
      }
  },
  {
      field: 'phone',
      headerName: 'Phone',
      width: 140,
      editable: false,
  },
  {
      field: "",
      headerName:"Action",
      sortable: false,
      width: 100,
      filterable: false,
      disableClickEventBubbling: true,
      renderCell: (params:any) => {
        const rowData = params.row;
        return <HospitalActionMenu rowData = {rowData} parentCallback = {handleCallback} />;
      }
    }
];

const getHospitals = () => {
  RequestApi.requestData("GET", getAllHospitals, {})
    .then( (data:any) => {
      setHospitalList(data);
      setShowSpinner(false);
  });
}

if(!hospitalsList.length && getHospitalFlag){
  setHospitalFlag(false);
  getHospitals();
}

const deleteHospitalAction  = () => {
  let deleteUserUrl = `${getAllHospitals}/${selectedHospital.id}`;
  RequestApi.requestData("DELETE", deleteUserUrl, {})
    .then( (response) => {
      setDeleteHospital(false);
      setSnackBar(true);
      setSnackBarMsg("Hospital got deleted Successfully for the record!");
      let newHospitalsList = hospitalsList.filter((hospital) => {
        return hospital['id'] != selectedHospital.id
      });
      setHospitalList(newHospitalsList);
  }).catch(function(e){
    console.log("e==>", e);
  });;
}

const handleClose = () => {
  resetFlags();
};

const saveDepartments = (type:string) => {
  let departmentIds:any = [];
  let departmentUrl = API.mapDepartmentsHospital;
  if("create" === type){
    departmentIds = mappedDepartments.map( (dept:any) => {return dept.id});
  }
  else{
    departmentIds = deptsForDelete;
    departmentUrl = API.unmapDepartmentsHospital;
  }
  let requestObj = {
    hospitalId:selectedHospital.id,
    departmentIds:departmentIds
  }
  console.log("requestObj==>", requestObj);
  RequestApi.requestData("POST", departmentUrl, requestObj)
    .then( (hosptialDetails:any) => {
      console.log("response==>", hosptialDetails);
      const newList:any = [...hospitalsList];
      let foundHospital:any = _.find(hospitalsList, {id:selectedHospital.id});
      let hospitalIndex = _.findIndex(newList, {id: selectedHospital.id});
      if(hospitalIndex !== -1){
        if("create" === type){
          foundHospital.departments = hosptialDetails.departments;
        }
        else {
          let tempDept = [...selectedHospital.departments]
          departmentIds.forEach( (id:any) => {
            _.remove(tempDept, {id:id});
          });
          foundHospital.departments = tempDept;
        }
        newList[hospitalIndex] = foundHospital;
        setHospitalList(newList);
      }
      setSnackBar(true);
      setSnackBarMsg("Hospital departments updated Successfully!");
      mapSchemesToDepartments(foundHospital);
  }).catch(function(e){
    console.log("error==>", e);
  });
}

const mapSchemesToDepartments = (hospital:any) => {
  let requestPayload = {
    hospitalId:hospital.id,
    schemeMapping:[]
  }

  // hospital
}

const saveDepartmentsScheme = () => {
  let requestData = {
    hospitalId:selectedHospital.id,
    schemeMapping:selectedHospital.schemeMapping
  };
  const updateHospital = LOCAL_HOST + API.HOSPITALS_URL;
  let putHospitalUrl = `${updateHospital}/${selectedHospital.id}`;
  RequestApi.requestData("PUT", putHospitalUrl, selectedHospital)
    .then( (hospitalDetails:any) => {
      setSnackBar(true);
      setSnackBarMsg("Schemes are updated to departments Successfully!");
  }).catch(function(e){
    console.log("error==>", e);
  });
}

const addAllDepartmentsToHospital = () => {
  let tempList = [...mappedDepartments];
  console.log("addAllDepartmentsToHospital==>", departmentList);
  departmentList.forEach( (dept:any) => {
    let foundDept = _.find(tempList, {id:dept.id});
    if(!foundDept){
      tempList.push(dept);
    }
  });
  setMappedDepartments(tempList);
}


const addDepartmentToScheme  = (type:string) => {
  console.log("addDepartmentToScheme", deptForMap);
  const newList:any = [...hospitalsList];
  let tmpSchemeMapping:any = {...selectedHospital.schemeMapping};
  console.log('tmpSchemeMapping==>', tmpSchemeMapping);
  let foundHospital:any = _.find(hospitalsList, {id:selectedHospital.id});
  let foundScheme:any = _.find(tmpSchemeMapping, {scheme:selectedScheme});
  let hospitalIndex = _.findIndex(newList, {id: selectedHospital.id});
  let schemeIndex = _.findIndex(tmpSchemeMapping, {scheme:selectedScheme});
  if(foundHospital && foundScheme){
    if(type === 'one'){
      if(deptForMap.id){
        let departments = [...foundScheme.departments];
        let foundDept = _.find(departments, {id:deptForMap.id});
        if(!foundDept){
          departments.push(deptForMap);
        }
        foundScheme.departments = departments;
      }
    }
    else{
      foundScheme.departments = departmentList;
    }
  }
  if(schemeIndex !== -1 && hospitalIndex !== -1){
    foundHospital.schemeMapping[schemeIndex] = foundScheme;
    newList[hospitalIndex] = foundHospital;
  }
  setSchemeDepartments(foundScheme.departments);
  setHospitalList(newList);
  setSelectedHospital(foundHospital);
}


const addDepartmentToHospital = () => {
  console.log("addDepartmentToHospital", deptForMap);
  if(deptForMap.id){
    const newList:any = [...hospitalsList];
    let departments = [...mappedDepartments];
    let foundHospital:any = _.find(hospitalsList, {id:selectedHospital.id});
    if(foundHospital){
      let foundDept = _.find(departments, {id:deptForMap.id});
      if(!foundDept){
        departments.push(deptForMap);
      }
      let foundIndex = _.findIndex(newList, {id: selectedHospital.id});
      if(foundIndex !== -1){
        foundHospital.departments = departments;
        newList[foundIndex] = foundHospital;
      }
      setHospitalList(newList);
      setMappedDepartments(departments);
      setSelectedHospital(foundHospital);
    }
  }
}

const deleteDepartmentsFromHospital = (departmentsToDelete:any) => {
  console.log("deleteDepartmentsFromHospital", departmentsToDelete);
  let tempDepts = [...mappedDepartments];
  deptsForDelete.forEach( (id) => {
    _.remove(tempDepts, {id:id});
  });
  setMappedDepartments(tempDepts);
  saveDepartments("delete");
}

const deleteDoctorsFromHospital = () => {
  let tempDoctors = [...mappedDoctors];
  unMappedDoctors.forEach( (id:any) => {
    _.remove(tempDoctors, {id:id});
  });
  setMappedDoctors(tempDoctors);
  saveDoctors("delete");
}


const saveDoctors = (type:string) => {
  let doctorIds:any = [];
  let doctorUrl = API.mapDoctorHospital;
  if("create" === type){
    doctorIds = [doctorForMap.id]
  }
  else{
    doctorIds = unMappedDoctors;
    doctorUrl = API.unmapDoctorsHospital;
  }
  let requestObj = {
    hospitalId:selectedHospital.id,
    doctorIds:doctorIds
  }
  console.log("requestObj==>", requestObj);
  RequestApi.requestData("POST", doctorUrl, requestObj)
    .then( (hosptialDetails:any) => {
      console.log("response==>", hosptialDetails);
      const newList:any = [...hospitalsList];
      let foundHospital:any = _.find(hospitalsList, {id:selectedHospital.id});
      let hospitalIndex = _.findIndex(newList, {id: selectedHospital.id});
      if(hospitalIndex !== -1){
        if("create" === type){
          let tempMappedDoctors:any =[...hosptialDetails.doctors];
          _.uniqBy(tempMappedDoctors, 'id');
          foundHospital.doctors = tempMappedDoctors;
          selectedHospital.doctors = tempMappedDoctors;
          setMappedDoctors(tempMappedDoctors);
        }
        else{
          let tempMappedDoctors:any =[...mappedDoctors];
          unMappedDoctors.forEach( (id:any) => {
            _.remove(tempMappedDoctors, {id:id});
          });
          setMappedDoctors(tempMappedDoctors);
          selectedHospital.doctors = tempMappedDoctors;
          foundHospital.doctors = tempMappedDoctors;
        }
        
        newList[hospitalIndex] = foundHospital;
        setHospitalList(newList);
      }
      setSnackBar(true);
      setSnackBarMsg("Hospital Doctors updated Successfully!");
  }).catch(function(e){
    console.log("error==>", e);
  });
}


const deleteDepartmentsToScheme = (departmentsToDelete:any) => {
  console.log("deleteDepartmentsToScheme", deptsForDelete);
  const newList:any = [...hospitalsList];
  let tmpSchemeMapping:any = {...selectedHospital.schemeMapping};
  console.log('tmpSchemeMapping==>', tmpSchemeMapping);
  let foundHospital:any = _.find(hospitalsList, {id:selectedHospital.id});
  let foundScheme:any = _.find(tmpSchemeMapping, {scheme:selectedScheme});
  let hospitalIndex = _.findIndex(newList, {id: selectedHospital.id});
  let schemeIndex = _.findIndex(tmpSchemeMapping, {scheme:selectedScheme});
  if(foundHospital && foundScheme){
    let departments = [...foundScheme.departments];
    deptsForDelete.forEach( (id) => {
      _.remove(departments, {id:id});
    });
    foundScheme.departments = departments;
  }
  if(schemeIndex !== -1 && hospitalIndex !== -1){
    foundHospital.schemeMapping[schemeIndex] = foundScheme;
    newList[hospitalIndex] = foundHospital;
  }
  setSchemeDepartments(foundScheme.departments);
  setHospitalList(newList);
  setSelectedHospital(foundHospital);
}

const setSelectedDoctor = (doctor:any) => {
  console.log("doctor==>", doctor);
  setDoctorMap(doctor);
}

const setSelectedDepartment = (department:any) => {
  console.log("department==>", department);
  setDeptForMap(department);
}

const onUpdateHospital = (hospital:any) => {
  const newList:any = [...hospitalsList];
  if(editHospital){
      setSnackBarMsg(`Hospital: ${hospital.name} Successfully updated to the record!`);
      let foundIndex = _.findIndex(newList, {id: hospital.id});
      if(foundIndex !== -1){
        newList[foundIndex] = hospital;
      }
      setHospitalList(newList);
      setEditHospital(false);
      setSnackBar(true);
  }
}

const editHospitalDialog = (
  <>
      <CustomEditHospitalDialog 
        open={editHospital}
        keepMounted
        onClose={handleClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">Edit Hospital</DialogTitle>
        <DialogContent dividers>
          <Hospitals isEditHospital={editHospital} hospitalDetails={selectedHospital} onUpdate={onUpdateHospital} />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            CLOSE
          </Button>
        </DialogActions>
      </CustomEditHospitalDialog>
      </>
);

const handleDeleteSelection = (e:any, type:string) => {
  if('doctors' === type){
    setUnMappedDoctors(e);
  }
  else{
    setDeptForDelete(e);
  }
  setEnableDeleteDept(e.length ? false : true);
}

const AddUpdateDepartmentDialog = (
  <Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={addDepartment} >
  <DialogTitle>
    Add/Delete Department
  </DialogTitle>
  <DialogContent dividers className={classes.dialogContent}>
   <AutoCompleteField provideDepartment = {setSelectedDepartment} type="Department" setDepartments={setDepartmentList}></AutoCompleteField> 
   <Button variant="contained" color="primary" size="medium" style= {{marginTop:'15px', marginLeft:'10px', marginRight:'10px'}}
      onClick={() => addDepartmentToHospital()}>
        Add
    </Button>
    <Button variant="contained" color="primary" size="medium" style= {{marginTop:'15px', marginRight:'10px'}}
      onClick={() => addAllDepartmentsToHospital()}>
        Add All
    </Button>
      <div>
        <div style={{float:'right', marginTop:'20px'}}>
        <Button variant="contained" color="secondary" size="small" disabled={enableDeleteDep} style= {{backgroundColor: "#f50057", marginBottom:'15px', marginLeft:'10px'}}
          onClick={() => deleteDepartmentsFromHospital(deptsForDelete)}  startIcon={<DeleteIcon />}>
            Delete
        </Button>
        </div>
        <div style={{ display:'flex', width: '100%', clear:'both', marginTop:'30px' }}>
          <DataGrid rows={mappedDepartments} columns={mappedDepartmentsCols} pageSize={5} autoHeight 
              disableSelectionOnClick
              checkboxSelection
              hideFooterPagination 
              disableColumnFilter
              disableColumnSelector
              onSelectionModelChange =  {(selected)=>handleDeleteSelection(selected, 'departments')}
          />
        </div>
      </div>
  </DialogContent>
  
  <DialogActions>
    <Button autoFocus onClick={handleClose} color="primary">
      CLOSE
    </Button>
    <Button autoFocus onClick={() => saveDepartments('create')}  color="primary" disabled={!enableDeleteDep}  variant="contained" style={{backgroundColor:"#4caf50"}}>
      SAVE DEPARTMENTS
    </Button>
  </DialogActions>
  </Dialog>
  );

  const mapSchemeDialog = (
    <Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={mapScheme} >
    <DialogTitle>
      Add/Delete Scheme to Department
    </DialogTitle>
    <DialogContent dividers className={classes.dialogContent}>
    <Grid container spacing={2}>
      <Grid item sm={12} md={6}>
        <div className={classes.toggleContainer}>
          <ToggleButtonGroup
            value={selectedScheme}
            exclusive
            onChange={handleScheme}
            aria-label="Scheme"
          >
            {hospitalSchemes.map((scheme:any) => {return (
                  <CustomToggleButton value= {scheme}> {scheme} </CustomToggleButton>
            )})}
            
          </ToggleButtonGroup>
        </div>
      </Grid>
      </Grid>
     <AutoCompleteField provideDepartment = {setSelectedDepartment} type="Department" setDepartments={setDepartmentList}></AutoCompleteField> 
     <Button variant="contained" color="primary" size="medium" style= {{marginTop:'15px', marginLeft:'10px', marginRight:'10px'}}
        onClick={() => addDepartmentToScheme('one')}>
          Add
      </Button>
      <Button variant="contained" color="primary" size="medium" style= {{marginTop:'15px', marginRight:'10px'}}
        onClick={() => addDepartmentToScheme('all')}>
          Add All
      </Button>
        <div>
          <div style={{float:'right', marginTop:'20px'}}>
          <Button variant="contained" color="secondary" size="small" disabled={enableDeleteDep} style= {{backgroundColor: "#f50057", marginBottom:'15px', marginLeft:'10px'}}
            onClick={() => deleteDepartmentsToScheme(deptsForDelete)}  startIcon={<DeleteIcon />}>
              Delete
          </Button>
          </div>
          <div style={{ display:'flex', width: '100%', clear:'both', marginTop:'30px' }}>
            <DataGrid rows={departmentsForScheme} columns={mappedDepartmentsCols} pageSize={5} autoHeight 
                disableSelectionOnClick
                checkboxSelection
                hideFooterPagination 
                disableColumnFilter
                disableColumnSelector
                onSelectionModelChange =  {(selected)=>handleDeleteSelection(selected, 'departments')}
            />
          </div>
        </div>
    </DialogContent>
    
    <DialogActions>
      <Button autoFocus onClick={handleClose} color="primary">
        CLOSE
      </Button>
      <Button autoFocus onClick={saveDepartmentsScheme} color="primary"  variant="contained" style={{backgroundColor:"#4caf50"}}>
        SAVE DEPARTMENTS
      </Button>
    </DialogActions>
    </Dialog>
    );
  

  const AddUpdateDoctorDialog = (
    <Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={addDoctor} >
    <DialogTitle>
      Add/Delete Doctor
    </DialogTitle>
    <DialogContent dividers className={classes.dialogContent}>
     <AutoCompleteField provideDepartment = {setSelectedDoctor} type="Doctor"></AutoCompleteField> 
     <Button variant="contained" color="primary" size="medium" style= {{marginTop:'15px', marginLeft:'10px', marginRight:'10px'}}
        onClick={() => saveDoctors('create')}>
          Add
      </Button>
      <div>
        <div style={{float:'right', marginTop:'20px'}}>
        <Button variant="contained" color="secondary" size="small" disabled={enableDeleteDep} style= {{backgroundColor: "#f50057", marginBottom:'15px', marginLeft:'10px'}}
          onClick={() => deleteDoctorsFromHospital()}  startIcon={<DeleteIcon />}>
            Delete
        </Button>
        </div>
        <div style={{ display:'flex', width: '100%', clear:'both', marginTop:'30px' }}>
          <DataGrid rows={mappedDoctors} columns={mappedDoctorCols} pageSize={5} autoHeight 
              disableSelectionOnClick
              checkboxSelection
              hideFooterPagination 
              disableColumnFilter
              disableColumnSelector
              onSelectionModelChange = {(selected)=>handleDeleteSelection(selected, 'doctors')}
          />
        </div>
      </div>
    </DialogContent>
    <DialogActions>
      <Button autoFocus onClick={handleClose} color="primary">
        CLOSE
      </Button>
    </DialogActions>
    </Dialog>
    );

  const deleteHospitalDialog = (
    <>
    <Dialog 
          open={deleteHospital}
          keepMounted
          onClose={handleClose}
          aria-labelledby="alert-dialog-slide-title"
          aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle id="alert-dialog-slide-title">Delete Hospital</DialogTitle>
          <DialogContent dividers>
            <DialogContentText id="alert-dialog-slide-description">
               Are you sure to Delete <br/>Hospital:{selectedHospital.name}?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} color="primary">
              CANCEL
            </Button>
            <Button onClick={deleteHospitalAction} color="primary">
              YES
            </Button>
          </DialogActions>
        </Dialog>
        </>
  );

  return (
      <>
          {AddUpdateDepartmentDialog}
          {deleteHospitalDialog}
          <NotificationBar snackBar={sankbar} severity="success" message={snackBarMsg}></NotificationBar>
          {editHospitalDialog}
          {AddUpdateDoctorDialog}
          {mapSchemeDialog}
          <Helmet>
              <title>
                  {PAGE_TITLE_ADMIN_HOSPITALS} | {APP_TITLE}
              </title>
          </Helmet>
          <div className={classes.root}>
              <PageTitle title={PAGE_TITLE_ADMIN_HOSPITALS} />
          </div>
        
          <div>
              <div style={{display:"block", float:'right'}}>
               <BulkUpload moduleName="Hospitals"></BulkUpload>
                
              <Button
                    variant="contained"
                    color="primary"
                    size="small"
                    startIcon={AddHospitalIcon}
                    className={classes.adduser}
                >
                  <Link href="/admin/hospital" className={classes.adduserLink}> Add Hospital</Link>
                </Button>
                </div>
              <div style={{clear:'both'}}></div>
          </div>
          {showSpinner ?  <CircularProgress disableShrink /> : 
          <div style={{ display:'flex', height: 425, width: '100%', clear:'both' }}>
              <DataGrid rows={hospitalsList} columns={columns} pageSize={5}
                  disableSelectionOnClick
              />
          </div>
          }
      </>
  );
};

export default HospitalsList;
