import React from 'react';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import IconButton from '@material-ui/core/IconButton';
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    menuItem:{
        fontSize:"10pt"
    },
    menu:{
        top:"10px"
    }
  })
);

export default function DoctorActionMenu(props:any) {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = (e:any) => {
      console.log("e.currentTarget==>", e.currentTarget)
    setAnchorEl(e.currentTarget);
  };

  const handleClose = (action:string) => {
    setAnchorEl(null);
    props.parentCallback(action, props.rowData);
  };

  return (
    <div>
      <IconButton
        aria-label="more"
        aria-controls="long-menu"
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="doctor-menu"
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
        className={classes.menu}
        key = "doctor-menu"
      >
        <MenuItem onClick={() => handleClose('EDIT_HOSPITAL')} className={classes.menuItem}>Edit Doctor</MenuItem>
        <MenuItem onClick={() => handleClose('DELETE_HOSPITAL')} className={classes.menuItem}>Delete Doctor</MenuItem>
      </Menu>
    </div>
  );
}
