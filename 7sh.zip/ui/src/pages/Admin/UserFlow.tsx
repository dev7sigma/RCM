import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import clsx from 'clsx';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import User from './User';


const ColorlibConnector = withStyles({
  alternativeLabel: {
    top: 22,
  },
  active: {
    '& $line': {
      backgroundImage:
        'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
    },
  },
  completed: {
    '& $line': {
      backgroundImage:
        'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
    },
  },
  line: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
})(StepConnector);

const useColorlibStepIconStyles = makeStyles({
  root: {
    backgroundColor: '#ccc',
    zIndex: 1,
    color: '#fff',
    width: 50,
    height: 50,
    display: 'flex',
    borderRadius: '50%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  active: {
    backgroundImage:
      'linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)',
    boxShadow: '0 4px 10px 0 rgba(0,0,0,.25)',
  },
  completed: {
    backgroundImage:
      'linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)',
  },
});

function ColorlibStepIcon(props:any) {
  const classes = useColorlibStepIconStyles();
  const { active, completed } = props;

  const icons:any = {
    1: <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAABJ0lEQVRIie2UsUoDQRCGPwQvBGxSGo1t+kBeIQ+jSQrBN/BRbAwBCy2SImUShRgSCHa+gQp3sbCLxc7Ksezu3eUWbPLDsNzNzP/P7M0NHBAIDWAIJGIPQDMk+SewM+xLfKUxtJBrG4QQSDwCcVbyUUnxXQiBicc3zl+LG03UBzWv5wM4DyEAaloGqDuPgfuQ5P+GCtADnoFvsTnQBaKy5GfACvf4LoF6HqI2cAs8AqNU5T5yba+uTqrADfBuJFyLv28h0zDfX9laXzsqaknMSwGBuSnw5Gm5JjFbC7EJ7U9Mx49H4ERi0rspU8BcFRVP0oWcbxYi1/OmyLLryHlXIKdI7B8i1JxnjekCON5HANRP5BNZAKf7kmtEqDmfoSZrC0yBS1KV/wIPZpB+ajyK1gAAAABJRU5ErkJggg=="/>,
    2: <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAkklEQVRIid2VawqAIBCEvyI6VHW9XvfMrlF/NlCzMo2wBpbFBzPMrrjwJ5TACMzAEhgK6IVrhyGC2I7OJaDksAorAAC15mSHTT0WBk/+AOEpfASOnHk5TsJB2gLFjbtBLywpB5m19nL0/SYn0QO79lf7Bl4t0Sy5juBrJDu/657nBk7rEihFRN0k02MScufI/CZWtYRYPcwfpK4AAAAASUVORK5CYII="/>,
    3: <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABmJLR0QA/wD/AP+gvaeTAAAAvElEQVRIie3SKw4CQRBF0cPHIrCj2AECgUFikVg0Dsku8Fgkli0g2QCKNaAIIXzMkHQgzEwPoOAmJapT/V5VdfMrVDHAGhuMUP+EcAMT7HB9iB2maJYRbmGGfSC4xTiNbXC+T2tbRYQ7WOAUCKwxRC2oq6CPFS5p3TnNe1kGd9EjlugWaKqNOQ7B/VyDpIDwI0mMwady1RKdRpH3lyuR+RNfnyDPIHrnsQZv83+DH3iDVwaZY8fw9RX9yeUGZ5c/XjzYJNsAAAAASUVORK5CYII="/>,
  };

  return (
    <div
      className={clsx(classes.root, {
        [classes.active]: active,
        [classes.completed]: completed,
      })}
    >
      {icons[String(props.icon)]}
    </div>
  );
}

ColorlibStepIcon.propTypes = {
  /**
   * Whether this step is active.
   */
  active: PropTypes.bool,
  /**
   * Mark the step as completed. Is passed to child components.
   */
  completed: PropTypes.bool,
  /**
   * The label displayed in the step icon.
   */
  icon: PropTypes.node,
};

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
  },
  button: {
    marginRight: theme.spacing(1),
  },
  instructions: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
  wizardFooter:{
    marginTop:"20px",
    paddingTop:"10px",
    borderTop:"1px solid #ccc"
  }
}));

function getSteps() {
  return ['User Details', 'Add Hospital', 'Add Departments'];
}

function getStepContent(step:any) {
  switch (step) {
    case 0:
      return <User></User>;
    case 1:
      return 'What is an ad group anyways?';
    case 2:
      return 'This is the bit I really care about!';
    default:
      return 'Unknown step';
  }
}

export default function UserFlow() {
  const classes = useStyles();
  const [activeStep, setActiveStep] = React.useState(1);
  const steps = getSteps();

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  return (
    <div className={classes.root}>
    
      <Stepper alternativeLabel activeStep={activeStep} connector={<ColorlibConnector />}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel StepIconComponent={ColorlibStepIcon}>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      <div>
        {activeStep === steps.length ? (
          <div>
            <Typography className={classes.instructions}>
              All steps completed - you&apos;re finished
            </Typography>
            <Button onClick={handleReset} className={classes.button}>
              Reset
            </Button>
          </div>
        ) : (
          <div>
            <Typography className={classes.instructions}>{getStepContent(activeStep)}</Typography>
            <div className={classes.wizardFooter}>
              <Button disabled={activeStep === 0} onClick={handleBack} className={classes.button}>
                Back
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={handleNext}
                className={classes.button}
              >
                {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
