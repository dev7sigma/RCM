import React, { ChangeEvent, useEffect, useMemo, useState } from "react";
import {
  withStyles,
  makeStyles,
  useTheme
} from '@material-ui/core/styles';

import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import clsx from  'clsx';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CircularProgress from '@material-ui/core/CircularProgress';
import {DoctorFormControls} from './DoctorFormControls'
import {API,  LOCAL_HOST } from "../../utils/constants";
import * as _ from "lodash";
import RequestApi from '../../service/RequestApi';
const getAllDepartments = LOCAL_HOST + API.DEPARMENTS;

const AutocompleteField = withStyles({
  root: {
    width:"250px",
    margin:"8px 9px",
    '& label.MuiInputLabel-root': {
      margin:'-10px 10px'
    },
    '& label.Mui-focused': {
      TransformStream:'translate(14px ,6px) scale(0.75)'
    },
    '& .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"]': {
      padding:0,
    },
  },
})(Autocomplete);


const UsersTextField = withStyles({
  root: {   
    width:"250px",
    margin:"8px 12px",
    '& label.MuiInputLabel-root': {
      fontSize:'10pt'
    },
    '& .MuiOutlinedInput-root': {
      '&:hover fieldset': {
        fontSize:'9pt'
      },
    },
  },
})(TextField);


const EmailTextField = withStyles({
  root: {
    width:"250px",
    margin:"8px 9px",
    '& label.MuiInputLabel-root': {
      fontSize:'10pt'
    },
    '& .MuiOutlinedInput-root': {
      '&:hover fieldset': {
        fontSize:'9pt'
      },
    },
  },
})(TextField);

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  muiSelect: {
    "& .MuiSelect-outlined": {
      fontSize: "10pt"
    }
  },
  select: {
    "& ul": {
      backgroundColor: "#f7f3f3",
    },
    "& li": {
      fontSize: 12,
    }
  },

  form:{
    display:"block"
  },
  margin: {
    margin: theme.spacing(1),
  },

  formControl: {
    margin: "0 10px",
    minWidth: 120,
  },
  InputLabel:{
    fontSize:'11pt',
    '& .MuiSelect-selectMenu' : {
      fontSize:'12pt',
    }
  },
  divStyling:{
    margin: "20px 0 0 0",
  },
 
  primaryButton:{
    backgroundColor:"#4caf50"
  },
  ml10:{
    marginLeft:"10px"
  }
}));

export function AutoCompleteDepartment(props:any) {
  const [autoCompleteOpen, setAutoCompleteOpen] = React.useState(false);
  const [departmentList, setDepartmentList] = React.useState(Array());
  const loading = !autoCompleteOpen && departmentList.length === 0;
  const [searchVal, setSearchValue] = React.useState('');
  const [selectedDepartment, setDepartmentValue] = React.useState([] as any);
  console.log("props.isEditDoctor==>", props.isEditDoctor);

  const onSearchTextChange = (event: ChangeEvent<HTMLInputElement>) =>{
    setSearchValue(event.target.value);
  }

  React.useEffect(() => {
    if(props.isEditDoctor){
      let selectedDepts = props.department.split(",");
      console.log("selectedDepts==>",selectedDepts);
      
      let deptList:any = [];
      deptList = departmentList.map( (dept:any) => {
        if(selectedDepts.includes(dept.name)){
          return dept;
        }
      });
      deptList = _.compact(deptList);
      setDepartmentValue(deptList);
      console.log("selectedDepartment==>",selectedDepartment);
      props.provideDepartment(deptList);
    }
  }, [ props.isEditDoctor]);

  
  const setDepartment = (dept:any) => {
    setDepartmentValue(dept);
    props.provideDepartment(dept);
  };

  React.useEffect(() => {
    
    let active = true;

    if (!loading) {
      return undefined;
    }
      
    if(!departmentList.length){
      RequestApi.requestData("GET", getAllDepartments, {})
        .then(data => {
          if (active) {
            setDepartmentList(data);
          }
      });
    }

    return () => {
      active = false;
    };
  }, [loading]);


return (
<AutocompleteField
  multiple
  style={{ width: 300, display:'inline-block' }}
  open={autoCompleteOpen}
  onOpen={() => {
    setAutoCompleteOpen(true);
  }}
  onClose={() => {
    setAutoCompleteOpen(false);
  }}
  getOptionSelected={(option:any, value:any) => option.name === value.name}
  getOptionLabel={(option:any) => option.name}
  options={departmentList}
  loading={loading}
  onChange={(event, newValue) => {
    setDepartment(newValue);
  }}
  value={selectedDepartment}
  renderInput={(params) => (
    <TextField
      {...params}
      label="Department"
      variant="standard"
      onChange = {onSearchTextChange}
      InputProps={{
        ...params.InputProps,
        endAdornment: (
          <React.Fragment>
            {loading ? <CircularProgress color="inherit" size={20} /> : null}
            {params.InputProps.endAdornment}
          </React.Fragment>
        ),
      }}
    />
  )}
/>
);
}


export default function Doctor(props:any) {
  const classes = useStyles();
  const theme = useTheme();

  const {
    handleInputValue,
    formIsValid,
    errors,
    resetValues,
    values,
    setDoctorDetails,
    setDepartmentValue
  } = DoctorFormControls();

  const DOCTORS_API = LOCAL_HOST + API.DOCTORS;
  const [show, setShow] = useState(true);
  const [department, setDepartment]  = useState('');

  useMemo(() => {
    if(props.isEditDoctor){
      console.log("doctorDetails==>", props.doctorDetails);
      setDoctorDetails(props.doctorDetails)
      setDepartment(props.doctorDetails.department);
      setShow(false);
    }
    else if(!props.isEditDoctor){
      setShow(true);
    }
  }, [props]);

  const addOrUpdateDoctor = (doctorData:any, type:string) => {
    let apiUrl = (type === 'add') ? DOCTORS_API : `${DOCTORS_API}/${doctorData.id}`;
    let apiMethod = (type === 'add') ? 'POST' : 'PUT';
    RequestApi.requestData(apiMethod, apiUrl, doctorData)
      .then( data => {
        if(data.id){
          resetValues();
        }
        props.onSubmit(data);
    });
  }

  const handleFormSubmit = async (e: any) => {
    e.preventDefault();
    const isValid = Object.values(errors).every((x) => x === "") && formIsValid();
    if (isValid) {
      if(!props.isEditDoctor){
        await addOrUpdateDoctor(values, 'add');
      }
      else{
        await addOrUpdateDoctor(values, 'update');
      }
    }
  };

  const setSelectedDepartment = (department:any) => {
    console.log("department==>", department);
    setDepartment(department);
    let departments = department.map( (dep:any) => {return dep.name});
    setDepartmentValue(departments.join(","));
  }

  return (
    <>
      <form className={classes.form} noValidate>
      <div className={classes.divStyling} key="1">
        <UsersTextField
          className={classes.margin}
          label="Doctor Name"
          variant="outlined"
          id="name"
          margin = "dense"
          name="name"
          required
          value={values.name}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['name']}
          helperText ={errors['name']}
          key="2"
          />

        <UsersTextField
          className={classes.margin}
          label="Registration No"
          variant="outlined"
          id="regNo"
          margin = "dense"
          name="regNo"
          required
          value={values.regNo}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['regNo']}
          helperText ={errors['regNo']}
          key="22"
          />

        <EmailTextField
          label="Email"
          variant="outlined"
          id="email"
          margin = "dense"
          name="email"
          required
          value={values.email}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['email']}
          helperText ={errors['email']}
          key="3"
        />
        </div>
       <div>
        <UsersTextField
          className={classes.margin}
          label="Qualification"
          variant="outlined"
          id="qualification"
          margin = "dense"
          name="qualification"
          required
          value={values.qualification}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['qualification']}
          helperText ={errors['qualification']}
          key="441"
        />
     
      <UsersTextField
          className={classes.margin}
          label="Phone"
          variant="outlined"
          id="contactNumber"
          margin = "dense"
          name="contactNumber"
          required
          value={values.contactNumber}
          onChange={handleInputValue}
          onBlur={handleInputValue}
          error={errors['contactNumber']}
          helperText ={errors['contactNumber']}
          key="446"
          />

      </div>
      <div style={{marginTop:'10px'}}>
        <AutoCompleteDepartment multiple provideDepartment = {setSelectedDepartment} isEditDoctor={props.isEditDoctor} department={department}></AutoCompleteDepartment>  
      </div>
      <div className={classes.divStyling}>
        <Button className={clsx(classes.primaryButton, classes.ml10)} variant="contained" 
         disabled={!formIsValid()}
         onClick = {handleFormSubmit}
        color="primary">
          {show ? 'Add' : "Save" }
        </Button>
      </div>
        
      </form>
    </>
  );
}


