import React, { useEffect, useMemo, useState } from "react";
import { makeStyles, Theme, withStyles, createStyles} from "@material-ui/core/styles";
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemText from '@material-ui/core/ListItemText';
import Button from '@material-ui/core/Button';
import RequestApi from '../../service/RequestApi';
import DialogTitle from '@material-ui/core/DialogTitle';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import { DropzoneAreaBase } from 'material-ui-dropzone';
import { API } from "../../utils/constants";
import axios from "axios";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flex: 1,
      display: "flex",
      flexDirection: "row",
      justifyContent: "space-between",
    } ,
    menuItem: {
      fontStyle:'bold',
      '&:active':{
        borderLeft: '4px solid #51bcda',
      },
      selected:{
      backgroundColor:'red !important' 
      }  
  }
}));

const StyledMenu = withStyles({
    paper: {
      border: '1px solid #d3d4d5'
    },
  })(Menu);
  
  const StyledMenuItem = withStyles((theme) => ({
    root: {
      '&:focus': {
        backgroundColor: '#27b8a6',
        '& .MuiListItemIcon-root, & .MuiListItemText-primary': {
          color: theme.palette.common.white,
        },
      },
    },
  }))(MenuItem);

  const CustomUploadDialog = withStyles({
    root: {
      '& .MuiDialog-paperWidthSm': {
       maxWidth:'875px !important'
      }
    },
  })(Dialog);

  export default function BulkUpload(props:any) {
    const classes = useStyles();
    const [anchorEl, setAnchorEl] = useState(null);
    const [bulkUpload, setBulkUpload] = useState(false);

    const handleClick = (event:any) => {
        setAnchorEl(event.currentTarget);
    };
    
    const closeMenu = () => {
      setAnchorEl(null);
    };

    const downloadFile = (fileName:string) =>{
        RequestApi.downloadFile(fileName).then( () => {
            console.log("file downloaded");
        }
        );
    }

    const openUpload = () => {
      setBulkUpload(true);
      closeMenu();
    }

    const handleClose = () => {
       setBulkUpload(false);
    };

    const [fileObjs, setFileObjs] = useState([] as any);
    const [fileName, setFileName] = useState("" as String);
    const uploadFile = () => {
      const formData = new FormData();

      formData.append('file', fileObjs);

        let uploadUrl = "";
        if("Users" === props.moduleName){
          uploadUrl = API.userBulkUploadUrl;
        } else if("Hospitals" === props.moduleName){
          uploadUrl = API.userBulkUploadUrl;
        } else if("Departments" === props.moduleName){
          uploadUrl = API.userBulkUploadUrl;
        } else if("Schemes" === props.moduleName){
          uploadUrl = API.userBulkUploadUrl;
        } else if("Doctors" === props.moduleName){
          uploadUrl = API.userBulkUploadUrl;
        }
        handleClose();
        props.showBackDrop(true);
        axios.post(uploadUrl, formData, {headers: { 'Content-Type': 'multipart/form-data' }})
        .then(response => {
            props.onUpload(response);
        })
        .catch(error => {
          handleClose();
        });
    }

    const changeHandler = (event:any) => {
      setFileObjs(event.target.files[0]);
      setFileName(event.target.files[0].name);
    };

    

    const bulkUploadDialog = (
        <>
        <CustomUploadDialog
        open={bulkUpload}
        keepMounted
        onClose={handleClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
        >
          <DialogTitle id="alert-dialog-slide-title">Upload Document for Bulk {props.moduleName}</DialogTitle>
              <DialogContent dividers  style={{ margin: '20px 0' }}>
              <label style={{ backgroundColor: '#007bff', display:"inline-block", color: '#fff', marginTop:10, cursor: 'pointer', padding: 15, borderRadius: 3 }}>
                Choose File
                
              <input
                style={{ display: 'none' }}
                type="file"
                onChange={changeHandler} />
            </label>
              <div style={{clear:"both", marginTop:"20px"}}> {fileName}</div>
              {/* <DropzoneAreaBase
                onAdd={(fileObjs) => {setFileObjs(fileObjs);  }}
                onDelete={(fileObj) => console.log('Removed File:', fileObj)}
                onAlert={(message, variant) => console.log(`${variant}: ${message}`)} fileObjects={[]}  
              /> */}
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClose} color="primary">
                  CLOSE
                </Button>
                <Button onClick={()=>uploadFile()}  color="primary"  variant="contained" style={{backgroundColor:"#4caf50"}}>
                  UPLOAD
                </Button>
              </DialogActions>
        </CustomUploadDialog>
      </>
      );

    return (
        <>
            {bulkUploadDialog}
              
              <Button
                  style={{marginRight:'20px', backgroundColor:'#27b8a6', padding:'5px 20px'}}
                  aria-controls="customized-menu"
                  variant="contained"
                  color="primary"
                  size="small"
                  onClick={handleClick}
                >
                  Bulk Upload
                </Button>
                <StyledMenu
                  id="customized-menu"
                  anchorEl={anchorEl}
                  keepMounted
                  open={Boolean(anchorEl)}
                  onClose={closeMenu}
                  className={classes.menuItem}
                  PaperProps={{
                    style: {
                      left: '50%',
                      transform: 'translateX(0%) translateY(45%)',
                    }
                  }}
                  
                >
                  <StyledMenuItem>
                    <ListItemText primary="Download Template" onClick={()=>downloadFile(props.moduleName)}></ListItemText>
                  </StyledMenuItem>
                  <StyledMenuItem>
                    <ListItemText primary="Upload Template" onClick={()=> openUpload()}/>
                  </StyledMenuItem>
                </StyledMenu>
        </>
    );
  }