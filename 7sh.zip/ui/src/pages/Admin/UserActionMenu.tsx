import React from 'react';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import IconButton from '@material-ui/core/IconButton';
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";


const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    menuItem:{
        fontSize:"10pt"
    },
    menu:{
        top:"10px"
    }
  })
);

export default function UserActionMenu(props:any) {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [showAddUser, setShowAddUser] = React.useState(false);
  const handleClick = (e:any) => {
    setAnchorEl(e.currentTarget);
  };

  const handleClose = (action:string) => {
    setAnchorEl(null);
    props.parentCallback(action, props.rowData);
  };

  return (
      <>
    <div>
      <IconButton
        aria-label="more"
        aria-controls="long-menu"
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="user-menu"
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
        className={classes.menu}
        key="user-menu"
      >
        <MenuItem onClick={() => handleClose('ADD_HOSPITAL')} className={classes.menuItem}>Update Hospital</MenuItem>
        <MenuItem onClick={() => handleClose('EDIT_USER')} className={classes.menuItem}>Edit User</MenuItem>
        <MenuItem onClick={() => handleClose('DELETE_USER')} className={classes.menuItem}>Delete User</MenuItem>
      </Menu>
    </div>
    </>
  );
}
