// icons
import HomeIcon from '@material-ui/icons/Home';
import DashboardIcon from '@material-ui/icons/BarChartOutlined';
import LocalHotelSharp from '@material-ui/icons/LocalHotelSharp';
import SettingsIcon from '@material-ui/icons/SettingsOutlined';
import SupervisedUserCircle from '@material-ui/icons/SupervisedUserCircle';
import LocalHospital from '@material-ui/icons/LocalHospital';

// components
import Home from '../pages/Home';
// import Dashboard from '../pages/Dashboard';
import HospitalsList from '../pages/Admin/HospitalsList';
import PatientsList from '../pages/PatientsList';
import DepartmentsList from '../pages/Admin/DepartmentsList';
import DoctorsList from '../pages/Admin/DoctorsList';
import UsersList from '../pages/Admin/UsersList';

// interface
import RouteItem from '../model/RouteItem.model';
import SchemesList from '../pages/Admin/SchemesList';
import Login from '../pages/Login';

console.log("index.ts");

export const AdminRoutes:Array<RouteItem> = [
{
    key: "router-gh",
    title: "Admin",
    tooltip: "Admin",
    enabled: true,
    icon: SettingsIcon,
    subRoutes: [
        {
            key: "router-admin-user",
            title: "Users",
            tooltip: "Users",
            path: "/admin/users",
            enabled: true,
            component: UsersList,
            icon: SupervisedUserCircle,
        }, 
        {
            key: "router-admin-hospital",
            title: "Hospitals",
            tooltip: "Hospitals",
            path: "/admin/hospitals",
            enabled: true,
            component: HospitalsList,
            icon: LocalHospital
        }, 
        {
            key: "router-admin-departments",
            title: "Departments",
            tooltip: "Departments",
            path: "/admin/departments",
            enabled: true,
            component: DepartmentsList
        }, 
        {
            key: "router-admin-schemes",
            title: "Schemes",
            tooltip: "Schemes",
            path: "/admin/schemes",
            enabled: true,
            component: SchemesList
        }, 
        {
            key: "router-admin-doctors",
            title: "Doctors",
            tooltip: "Doctors",
            path: "/admin/doctors",
            enabled: true,
            component: DoctorsList
        }, 
        {
            key: "router-admin-login",
            title: "Login",
            tooltip: "Login",
            path: "/admin/login",
            enabled: true,
            component: Login
        }
    ]
}
];
// basic app routes

export const basicRoutes: Array<RouteItem> = [
    {
        key: "router-home",
        title: "Home",
        tooltip: "Home",
        path: "/",
        enabled: true,
        component: Home,
        icon: HomeIcon,
        appendDivider: true
    }
];

export const nonAdminRoutes: Array<RouteItem> = [
    {
        key: "router-patient",
        title: "Patients",
        tooltip: "Patients",
        path: "/patients",
        enabled: true,
        component: PatientsList,
        icon: LocalHotelSharp,
        appendDivider: true
    }
   /* {
        key: "router-uielements",
        title: "UI Elements",
        tooltip: "UI Elements",
        path: "/uielements",
        enabled: true,
        component: ContactForm,
        appendDivider: true
    },
     {
        key: "router-settings",
        title: "Settings",
        tooltip: "Settings",
        path: "/settings",
        enabled: true,
        component: Settings,
        icon: SettingsIcon
    }, */
]

let isAdmin = true;
let menuItems = [];
menuItems = (isAdmin) ? [...basicRoutes, ...AdminRoutes, ...nonAdminRoutes] : [...basicRoutes, ...nonAdminRoutes]

export const routes: Array<RouteItem> = [
    ...menuItems
];